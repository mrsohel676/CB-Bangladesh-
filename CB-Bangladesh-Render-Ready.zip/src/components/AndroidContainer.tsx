import React, { useState, useEffect } from 'react';
import {
  MessageSquare,
  ShieldCheck,
  User,
  Shield,
  Smartphone,
  Maximize2,
  Minimize2,
  Wifi,
  Battery,
  Signal,
  Inbox,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { translations } from '../utils/i18n';
import { ActiveTab } from '../types';

interface AndroidContainerProps {
  children: React.ReactNode;
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  hideBottomNav?: boolean;
}

export const AndroidContainer: React.FC<AndroidContainerProps> = ({
  children,
  activeTab,
  onTabChange,
  hideBottomNav = false,
}) => {
  const { user, language } = useAuth();
  const t = translations[language];

  const [currentTime, setCurrentTime] = useState('');
  const [isFrameMode, setIsFrameMode] = useState(true);

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateClock();
    const interval = setInterval(updateClock, 10000);
    return () => clearInterval(interval);
  }, []);

  const isAdmin = user?.role === 'admin';

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-0 sm:p-4 text-slate-100 selection:bg-emerald-500 selection:text-white">
      {/* Top Device Mode Toolbar for desktop / large screens */}
      <div className="hidden sm:flex items-center justify-between w-full max-w-md mb-2 px-2 text-xs text-slate-400">
        <div className="flex items-center gap-1.5 font-bold text-emerald-400">
          <ShieldCheck className="w-4 h-4" />
          <span>CB Bangladesh (Android)</span>
        </div>
        <button
          onClick={() => setIsFrameMode(!isFrameMode)}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:text-white transition"
        >
          {isFrameMode ? <Maximize2 className="w-3.5 h-3.5" /> : <Minimize2 className="w-3.5 h-3.5" />}
          <span>{isFrameMode ? 'Full Width' : 'Phone Frame'}</span>
        </button>
      </div>

      {/* Android Device Shell Container */}
      <div
        className={`w-full transition-all duration-300 flex flex-col bg-slate-950 relative overflow-hidden ${
          isFrameMode
            ? 'max-w-md h-[100dvh] sm:h-[840px] sm:max-h-[92vh] sm:rounded-[40px] sm:border-[8px] sm:border-slate-800 sm:shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)]'
            : 'max-w-4xl h-[100dvh] sm:h-[90vh] sm:rounded-2xl sm:border border-slate-800'
        }`}
      >
        {/* Android Status Bar */}
        <div className="h-7 px-6 bg-slate-900/90 text-slate-300 flex items-center justify-between text-[11px] font-semibold select-none shrink-0 z-30">
          <span>{currentTime || '12:00'}</span>

          {/* Android Camera Hole Punch Simulation */}
          <div className="hidden sm:block w-3 h-3 rounded-full bg-black border border-slate-800 mx-auto" />

          <div className="flex items-center gap-1.5 text-slate-400">
            <Signal className="w-3 h-3 text-emerald-400" />
            <Wifi className="w-3 h-3 text-emerald-400" />
            <Battery className="w-3.5 h-3.5 text-emerald-400" />
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-hidden relative flex flex-col">{children}</div>

        {/* Android Bottom Navigation Bar (Material 3 Pill Style) */}
        {!hideBottomNav && user && (
          <div className="h-16 bg-slate-900/95 border-t border-slate-800 px-3 flex items-center justify-around shrink-0 z-30 backdrop-blur">
            {/* Tab 1: Inbox */}
            <button
              onClick={() => onTabChange('inbox')}
              className={`flex flex-col items-center justify-center flex-1 py-1 transition group relative ${
                activeTab === 'inbox' ? 'text-emerald-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div
                className={`px-4 py-1 rounded-full transition ${
                  activeTab === 'inbox' ? 'bg-emerald-500/20' : 'bg-transparent'
                }`}
              >
                <MessageSquare className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-bold mt-0.5 tracking-tight">{t.inboxTab}</span>
            </button>

            {/* Tab 2: Official Account */}
            <button
              onClick={() => onTabChange('official')}
              className={`flex flex-col items-center justify-center flex-1 py-1 transition group relative ${
                activeTab === 'official' ? 'text-emerald-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div
                className={`px-4 py-1 rounded-full transition ${
                  activeTab === 'official' ? 'bg-emerald-500/20' : 'bg-transparent'
                }`}
              >
                <Shield className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-bold mt-0.5 tracking-tight">{t.officialTab}</span>
            </button>

            {/* Tab 3: Admin Queue (Visible if Admin role) */}
            {isAdmin && (
              <button
                onClick={() => onTabChange('admin')}
                className={`flex flex-col items-center justify-center flex-1 py-1 transition group relative ${
                  activeTab === 'admin' ? 'text-emerald-400' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <div
                  className={`px-4 py-1 rounded-full transition ${
                    activeTab === 'admin' ? 'bg-emerald-500/20' : 'bg-transparent'
                  }`}
                >
                  <Inbox className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold mt-0.5 tracking-tight">{t.adminTab}</span>
              </button>
            )}

            {/* Tab 4: Profile */}
            <button
              onClick={() => onTabChange('profile')}
              className={`flex flex-col items-center justify-center flex-1 py-1 transition group relative ${
                activeTab === 'profile' ? 'text-emerald-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div
                className={`px-4 py-1 rounded-full transition ${
                  activeTab === 'profile' ? 'bg-emerald-500/20' : 'bg-transparent'
                }`}
              >
                <User className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-bold mt-0.5 tracking-tight">{t.profileTab}</span>
            </button>
          </div>
        )}

        {/* Android Gesture Bar / Home Pill */}
        <div className="h-2 bg-slate-900 flex items-center justify-center shrink-0">
          <div className="w-28 h-1 rounded-full bg-slate-600/70" />
        </div>
      </div>
    </div>
  );
};
