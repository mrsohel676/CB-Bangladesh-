import React, { useState, useEffect, useCallback } from 'react';
import {
  ShieldCheck,
  Inbox,
  Users,
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  XCircle,
  MessageSquare,
  Search,
  Filter,
  CheckCheck,
  ChevronRight,
  Lock,
  Calendar,
  Phone,
  Mail,
  MapPin,
  CreditCard,
  UserCheck,
} from 'lucide-react';
import { Conversation, User, Report, PublicUser } from '../types';
import { useAuth } from '../context/AuthContext';
import { translations } from '../utils/i18n';
import { ConversationScreen } from './ConversationScreen';

export const AdminDashboard: React.FC = () => {
  const { user, token, language } = useAuth();
  const t = translations[language];

  const [activeSubTab, setActiveSubTab] = useState<'queue' | 'users' | 'reports'>('queue');
  const [conversationsQueue, setConversationsQueue] = useState<Conversation[]>([]);
  const [usersList, setUsersList] = useState<User[]>([]);
  const [reportsList, setReportsList] = useState<Report[]>([]);
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);
  const [activeTargetUser, setActiveTargetUser] = useState<PublicUser | undefined>(undefined);
  const [filterUnreadOnly, setFilterUnreadOnly] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  // Inspection modal for full user NID data
  const [inspectUser, setInspectUser] = useState<User | null>(null);

  // Fetch admin conversations queue
  const fetchAdminQueue = useCallback(async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/admin/conversations', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setConversationsQueue(data.conversations);
      }
    } catch (err) {
      console.error('Failed to fetch admin conversations queue:', err);
    } finally {
      setIsLoading(false);
    }
  }, [token]);

  // Fetch all registered users for verification audit
  const fetchUsers = useCallback(async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/admin/users', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setUsersList(data.users);
      }
    } catch (err) {
      console.error('Failed to fetch users list:', err);
    }
  }, [token]);

  // Fetch reports
  const fetchReports = useCallback(async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/admin/reports', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setReportsList(data.reports);
      }
    } catch (err) {
      console.error('Failed to fetch reports:', err);
    }
  }, [token]);

  useEffect(() => {
    fetchAdminQueue();
    fetchUsers();
    fetchReports();
    const interval = setInterval(() => {
      fetchAdminQueue();
    }, 4000);
    return () => clearInterval(interval);
  }, [fetchAdminQueue, fetchUsers, fetchReports]);

  // Toggle user verification
  const handleToggleVerification = async (userId: string, currentStatus: boolean) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/admin/users/${userId}/verify`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ isNidVerified: !currentStatus }),
      });
      if (res.ok) {
        fetchUsers();
        if (inspectUser && inspectUser.id === userId) {
          setInspectUser((prev) => (prev ? { ...prev, isNidVerified: !currentStatus } : null));
        }
      }
    } catch (err) {
      console.error('Failed to update verification:', err);
    }
  };

  // Open conversation from queue
  const handleOpenConversation = (conv: any) => {
    const otherParticipantId = conv.participants.find((p: string) => p !== user?.id) || 'unknown';
    const targetUserRecord = usersList.find((u) => u.id === otherParticipantId);

    const publicTarget: PublicUser = targetUserRecord
      ? {
          id: targetUserRecord.id,
          fullName: targetUserRecord.fullName,
          isNidVerified: targetUserRecord.isNidVerified,
          role: targetUserRecord.role,
        }
      : {
          id: otherParticipantId,
          fullName: conv.participantNames?.[otherParticipantId] || 'User',
          isNidVerified: true,
          role: 'user',
        };

    setActiveTargetUser(publicTarget);
    setSelectedConversationId(conv.id);
  };

  // Next in queue handler
  const handleNextInQueue = () => {
    if (!selectedConversationId) return;
    const currentIndex = conversationsQueue.findIndex((c) => c.id === selectedConversationId);
    if (currentIndex !== -1 && currentIndex < conversationsQueue.length - 1) {
      handleOpenConversation(conversationsQueue[currentIndex + 1]);
    } else if (conversationsQueue.length > 0) {
      // Loop back to first or exit
      handleOpenConversation(conversationsQueue[0]);
    }
  };

  // Filtered queue items
  const filteredQueue = conversationsQueue.filter((c) => {
    const names = Object.values(c.participantNames || {}).join(' ').toLowerCase();
    const matchesSearch = names.includes(searchQuery.toLowerCase());
    const unread = (c.unreadCount?.[user?.id || ''] || 0) > 0;
    if (filterUnreadOnly) {
      return matchesSearch && unread;
    }
    return matchesSearch;
  });

  // If a conversation is actively open inside Admin mode
  if (selectedConversationId) {
    return (
      <div className="flex flex-col h-full bg-slate-950">
        {/* Queue Navigation Header Bar */}
        <div className="px-4 py-2 bg-emerald-950/80 border-b border-emerald-500/30 flex items-center justify-between text-xs z-30">
          <div className="flex items-center gap-2 text-emerald-300 font-bold">
            <Inbox className="w-4 h-4" />
            <span>Admin Queue Mode</span>
          </div>
          <button
            onClick={handleNextInQueue}
            className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition shadow"
          >
            <span>{t.nextInQueue}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <ConversationScreen
          conversationId={selectedConversationId}
          targetUser={activeTargetUser}
          onBack={() => {
            setSelectedConversationId(null);
            fetchAdminQueue();
          }}
        />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 pb-24 overflow-y-auto custom-scrollbar">
      {/* Admin Top Header */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 space-y-3 shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center font-bold text-white text-base shadow-md">
              🛡️
            </div>
            <div>
              <h1 className="text-base font-black text-white flex items-center gap-2">
                CB Bangladesh Official
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.5 rounded font-bold">
                  Admin Central
                </span>
              </h1>
              <p className="text-[11px] text-slate-400">Verification & Organized Queue Management</p>
            </div>
          </div>
        </div>

        {/* Sub Navigation Tabs */}
        <div className="grid grid-cols-3 gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setActiveSubTab('queue')}
            className={`py-2 rounded-lg font-bold transition flex items-center justify-center gap-1.5 ${
              activeSubTab === 'queue'
                ? 'bg-emerald-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Inbox className="w-3.5 h-3.5" />
            <span>Queue ({conversationsQueue.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('users')}
            className={`py-2 rounded-lg font-bold transition flex items-center justify-center gap-1.5 ${
              activeSubTab === 'users'
                ? 'bg-emerald-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>NID Registry ({usersList.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('reports')}
            className={`py-2 rounded-lg font-bold transition flex items-center justify-center gap-1.5 ${
              activeSubTab === 'reports'
                ? 'bg-emerald-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Reports ({reportsList.length})</span>
          </button>
        </div>
      </div>

      {/* SUB-TAB 1: ORGANIZED INCOMING CONVERSATIONS QUEUE */}
      {activeSubTab === 'queue' && (
        <div className="p-4 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-sm font-bold text-white">{t.adminQueueTitle}</h2>
              <p className="text-xs text-slate-400">{t.queueDesc}</p>
            </div>

            {/* Filter controls */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setFilterUnreadOnly(!filterUnreadOnly)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition flex items-center gap-1.5 ${
                  filterUnreadOnly
                    ? 'bg-emerald-600/30 border-emerald-500 text-emerald-300'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <Filter className="w-3 h-3" />
                <span>Unread / New Only</span>
              </button>
            </div>
          </div>

          {/* Search */}
          <div className="relative">
            <input
              type="text"
              placeholder="Search user name in queue..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:border-emerald-500 outline-none"
            />
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          </div>

          {/* Queue Items */}
          <div className="space-y-2.5">
            {filteredQueue.length === 0 ? (
              <div className="py-12 text-center rounded-2xl bg-slate-900/40 border border-slate-800 text-xs text-slate-400">
                No conversations currently in this queue.
              </div>
            ) : (
              filteredQueue.map((conv, index) => {
                const otherId = conv.participants.find((p) => p !== user?.id) || '';
                const otherName = conv.participantNames?.[otherId] || 'User';
                const unreadCount = conv.unreadCount?.[user?.id || ''] || 0;
                const isUnread = unreadCount > 0;
                const timeString = new Date(conv.updatedAt).toLocaleString([], {
                  month: 'short',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                });

                return (
                  <div
                    key={conv.id}
                    className={`p-3.5 rounded-2xl border transition flex items-center justify-between gap-3 ${
                      isUnread
                        ? 'bg-emerald-950/30 border-emerald-500/50 shadow-md'
                        : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      {/* Queue position index */}
                      <span className="w-6 h-6 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-[10px] font-bold text-slate-400 shrink-0">
                        #{index + 1}
                      </span>

                      <div className="min-w-0">
                        <div className="flex items-center gap-2 mb-0.5">
                          <h4 className="text-xs font-bold text-white truncate">{otherName}</h4>
                          {isUnread && (
                            <span className="px-1.5 py-0.5 rounded bg-emerald-500 text-slate-950 font-black text-[9px] uppercase tracking-wider">
                              NEW ({unreadCount})
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-300 truncate">
                          {conv.lastMessage?.hasImage && '📷 '}
                          {conv.lastMessage?.text || 'No message content'}
                        </p>
                        <p className="text-[10px] text-slate-400 mt-1">Arrived: {timeString}</p>
                      </div>
                    </div>

                    <button
                      onClick={() => handleOpenConversation(conv)}
                      className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shrink-0 shadow transition"
                    >
                      <span>Open</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* SUB-TAB 2: USER IDENTITY & NID AUDIT REGISTRY */}
      {activeSubTab === 'users' && (
        <div className="p-4 space-y-4">
          <div>
            <h2 className="text-sm font-bold text-white">{t.userDirectory}</h2>
            <p className="text-xs text-slate-400">{t.adminAccessOnly}</p>
          </div>

          <div className="space-y-3">
            {usersList.map((u) => (
              <div
                key={u.id}
                className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-emerald-400 font-bold text-xs">
                      {u.fullName.substring(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                        {u.fullName}
                        {u.role === 'admin' && (
                          <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-1 rounded font-bold">
                            Admin
                          </span>
                        )}
                      </h4>
                      <p className="text-[11px] text-slate-400 font-mono">
                        NID: {u.nidNumber} • Age: {u.age} ({u.dob})
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                        u.isNidVerified
                          ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
                          : 'bg-amber-950/60 border-amber-500/40 text-amber-300'
                      }`}
                    >
                      {u.isNidVerified ? 'NID Verified' : 'Pending Verification'}
                    </span>
                  </div>
                </div>

                {/* Quick inspect details */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80">
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <Phone className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>{u.phone}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <Mail className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span className="truncate">{u.email}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-300 col-span-1 sm:col-span-2">
                    <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span className="truncate">
                      Perm: {u.permanentAddress?.division}, {u.permanentAddress?.district}, {u.permanentAddress?.upazila} ({u.permanentAddress?.details})
                    </span>
                  </div>
                </div>

                {/* Admin Actions */}
                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    onClick={() => setInspectUser(u)}
                    className="px-3 py-1.5 rounded-xl border border-slate-700 text-xs font-semibold text-slate-300 hover:bg-slate-800 transition"
                  >
                    View Full Record
                  </button>
                  {u.role !== 'admin' && (
                    <button
                      onClick={() => handleToggleVerification(u.id, u.isNidVerified)}
                      className={`px-3 py-1.5 rounded-xl font-bold text-xs transition ${
                        u.isNidVerified
                          ? 'bg-rose-950/50 border border-rose-500/40 text-rose-300 hover:bg-rose-900/50'
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow'
                      }`}
                    >
                      {u.isNidVerified ? 'Revoke Verification' : 'Verify NID Badge'}
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-TAB 3: INCIDENT SAFETY REPORTS */}
      {activeSubTab === 'reports' && (
        <div className="p-4 space-y-4">
          <div>
            <h2 className="text-sm font-bold text-white">Incident & Safety Reports</h2>
            <p className="text-xs text-slate-400">Submitted by verified users for admin review</p>
          </div>

          {reportsList.length === 0 ? (
            <div className="py-12 text-center rounded-2xl bg-slate-900/40 border border-slate-800 text-xs text-slate-400">
              No incident reports submitted. Platform health is optimal.
            </div>
          ) : (
            reportsList.map((rep) => (
              <div
                key={rep.id}
                className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2"
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-rose-400 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4" />
                    {rep.reason}
                  </span>
                  <span className="text-slate-400 text-[10px]">
                    {new Date(rep.createdAt).toLocaleString()}
                  </span>
                </div>
                <p className="text-xs text-slate-300">
                  Reported User ID: <span className="font-mono text-white">{rep.reportedUserId}</span>
                </p>
                <p className="text-xs text-slate-400">
                  Reporter ID: <span className="font-mono">{rep.reporterId}</span>
                </p>
              </div>
            ))
          )}
        </div>
      )}

      {/* Full Record Inspection Modal */}
      {inspectUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-emerald-500/40 rounded-3xl w-full max-w-lg max-h-[85vh] overflow-y-auto p-6 space-y-5 shadow-2xl custom-scrollbar">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <UserCheck className="w-5 h-5 text-emerald-400" />
                Verified Citizen Dossier
              </div>
              <button
                onClick={() => setInspectUser(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <p className="text-slate-400">Full Legal Name:</p>
                <p className="text-sm font-bold text-white">{inspectUser.fullName}</p>
                <p className="text-slate-400">Date of Birth & Age:</p>
                <p className="font-semibold text-emerald-300">{inspectUser.dob} ({inspectUser.age} Years Old - 18+ Validated)</p>
                <p className="text-slate-400">National ID (NID) Number:</p>
                <p className="font-mono font-bold text-white">{inspectUser.nidNumber}</p>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <p className="text-slate-400">Contact & Addresses:</p>
                <p className="text-white">Phone: {inspectUser.phone}</p>
                <p className="text-white">Email: {inspectUser.email}</p>
                <p className="text-white">
                  Permanent: {inspectUser.permanentAddress?.division}, {inspectUser.permanentAddress?.district}, {inspectUser.permanentAddress?.upazila} ({inspectUser.permanentAddress?.details})
                </p>
                <p className="text-white">
                  Current: {inspectUser.currentAddress?.division}, {inspectUser.currentAddress?.district}, {inspectUser.currentAddress?.upazila} ({inspectUser.currentAddress?.details})
                </p>
              </div>

            </div>

            <button
              onClick={() => setInspectUser(null)}
              className="w-full py-2.5 rounded-xl bg-slate-800 text-white font-bold text-xs"
            >
              Close Record
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
