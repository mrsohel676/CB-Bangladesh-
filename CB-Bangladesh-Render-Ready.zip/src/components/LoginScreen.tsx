import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  Phone,
  ArrowRight,
  AlertCircle,
  Eye,
  EyeOff,
  UserPlus,
  Shield,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { translations } from '../utils/i18n';

interface LoginScreenProps {
  onSwitchToRegister: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onSwitchToRegister }) => {
  const { login, language } = useAuth();
  const t = translations[language];

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!identifier.trim()) {
      setErrorMsg('Please enter your phone number or email.');
      return;
    }

    if (!password) {
      setErrorMsg('Please enter your password.');
      return;
    }

    setIsLoading(true);
    const res = await login(identifier.trim(), password);
    setIsLoading(false);

    if (!res.success) {
      setErrorMsg(res.error || 'Invalid credentials.');
    }
  };

  return (
    <div className="w-full max-w-md mx-auto p-4 sm:p-6 pb-24 text-slate-100 flex flex-col justify-center min-h-[80vh]">
      {/* Brand Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-emerald-600/20 border border-emerald-500/30 text-emerald-400 mb-3 shadow-xl shadow-emerald-950/50">
          <ShieldCheck className="w-9 h-9" />
        </div>
        <h1 className="text-3xl font-black text-white tracking-tight">{t.appName}</h1>
        <p className="text-xs text-emerald-400 font-semibold tracking-wider uppercase mt-1">
          {t.tagline}
        </p>
        <p className="text-xs text-slate-400 mt-2 max-w-xs mx-auto leading-relaxed">
          {t.privacyGuarantee}
        </p>
      </div>

      {/* Error Message */}
      {errorMsg && (
        <div className="p-4 mb-6 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs flex items-start gap-3 animate-shake">
          <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="flex-1 font-medium">{errorMsg}</div>
        </div>
      )}

      {/* Login Form */}
      <form onSubmit={handleSubmit} className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1.5">
            Phone Number or Email Address
          </label>
          <div className="relative">
            <input
              type="text"
              required
              placeholder="e.g. +8801812345678 or admin@cb.bd"
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              className="w-full pl-3.5 pr-10 py-3 rounded-xl bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-sm text-white placeholder-slate-500 outline-none transition"
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500">
              <Phone className="w-4 h-4" />
            </div>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1.5">
            {t.passwordLabel}
          </label>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              required
              placeholder="Enter your account password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full pl-3.5 pr-10 py-3 rounded-xl bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-sm text-white placeholder-slate-500 outline-none transition"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className="w-full mt-2 py-3.5 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/60 transition active:scale-[0.99]"
        >
          {isLoading ? (
            <span className="inline-flex items-center gap-2">
              <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Signing In...
            </span>
          ) : (
            <>
              <span>{t.loginButton}</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>

        <div className="text-center pt-3 border-t border-slate-800/80">
          <button
            type="button"
            onClick={onSwitchToRegister}
            className="w-full py-2.5 px-4 rounded-xl border border-emerald-500/30 bg-emerald-950/20 hover:bg-emerald-950/40 text-emerald-400 font-semibold text-xs flex items-center justify-center gap-2 transition"
          >
            <UserPlus className="w-4 h-4" />
            <span>Create New Account (18+ NID Verified)</span>
          </button>
        </div>
      </form>

      {/* Official Information Footer */}
      <div className="mt-8 text-center text-[11px] text-slate-500 flex items-center justify-center gap-1.5">
        <Shield className="w-3.5 h-3.5 text-emerald-500" />
        <span>End-to-end privacy shielding • Bangladesh Cyber Compliance</span>
      </div>
    </div>
  );
};

