import React, { useState, useMemo } from 'react';
import {
  Shield,
  ShieldCheck,
  UserCheck,
  Calendar,
  Phone,
  Mail,
  MapPin,
  CreditCard,
  Lock,
  FileCheck2,
  AlertCircle,
  CheckCircle,
  Eye,
  EyeOff,
  ArrowRight,
  Info,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { translations } from '../utils/i18n';
import { BD_DIVISIONS, BD_DISTRICTS } from '../utils/bangladeshLocations';
import { TermsModal } from './TermsModal';

interface RegisterScreenProps {
  onSwitchToLogin: () => void;
}

export const RegisterScreen: React.FC<RegisterScreenProps> = ({ onSwitchToLogin }) => {
  const { register, language } = useAuth();
  const t = translations[language];

  // Form State
  const [fullName, setFullName] = useState('');
  const [dob, setDob] = useState('');
  const [gender, setGender] = useState<'male' | 'female' | 'other'>('male');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Address State
  const [permDivision, setPermDivision] = useState('Dhaka');
  const [permDistrict, setPermDistrict] = useState('Dhaka');
  const [permUpazila, setPermUpazila] = useState('');
  const [permDetails, setPermDetails] = useState('');

  const [sameAsPermanent, setSameAsPermanent] = useState(true);
  const [currDivision, setCurrDivision] = useState('Dhaka');
  const [currDistrict, setCurrDistrict] = useState('Dhaka');
  const [currUpazila, setCurrUpazila] = useState('');
  const [currDetails, setCurrDetails] = useState('');

  // NID number only; card image upload is intentionally not required.
  const [nidNumber, setNidNumber] = useState('');

  // Terms and conditions
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);

  // UI state
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Age calculation
  const calculatedAge = useMemo(() => {
    if (!dob) return null;
    const birthDate = new Date(dob);
    if (isNaN(birthDate.getTime())) return null;
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  }, [dob]);

  const isAgeValid = calculatedAge !== null && calculatedAge >= 18;
  const isUnderAge = calculatedAge !== null && calculatedAge < 18;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    // Validations
    if (!fullName.trim()) {
      setErrorMsg('Please enter your full legal name matching your National ID.');
      return;
    }

    if (!dob) {
      setErrorMsg('Please enter your date of birth.');
      return;
    }

    if (calculatedAge === null || calculatedAge < 18) {
      setErrorMsg('Age restriction: You must be at least 18 years old to register. Users under 18 cannot register on CB Bangladesh.');
      return;
    }

    if (!phone.trim()) {
      setErrorMsg('Please enter your mobile phone number.');
      return;
    }

    if (!email.trim() || !email.includes('@')) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }

    const cleanNid = nidNumber.trim().replace(/\s+/g, '');
    if (!/^\d{10}$|^\d{13}$|^\d{17}$/.test(cleanNid)) {
      setErrorMsg('Please enter a valid 10, 13, or 17 digit Bangladesh National ID (NID) / Smart Card number.');
      return;
    }

    if (password.length < 6) {
      setErrorMsg('Password must be at least 6 characters long.');
      return;
    }

    if (password !== confirmPassword) {
      setErrorMsg('Password confirmation does not match.');
      return;
    }

    if (!termsAccepted) {
      setErrorMsg('You must review and agree to the Terms & Conditions before completing registration.');
      return;
    }

    setIsSubmitting(true);

    const payload = {
      fullName: fullName.trim(),
      dob,
      gender,
      phone: phone.trim(),
      email: email.trim(),
      password,
      permanentAddress: {
        division: permDivision,
        district: permDistrict,
        upazila: permUpazila.trim() || 'Sadar',
        details: permDetails.trim() || 'Provided on NID file',
      },
      currentAddress: sameAsPermanent
        ? {
            division: permDivision,
            district: permDistrict,
            upazila: permUpazila.trim() || 'Sadar',
            details: permDetails.trim() || 'Provided on NID file',
          }
        : {
            division: currDivision,
            district: currDistrict,
            upazila: currUpazila.trim() || 'Sadar',
            details: currDetails.trim() || 'Provided on file',
          },
      nidNumber: cleanNid,
      termsAccepted: true,
    };

    const res = await register(payload);
    setIsSubmitting(false);

    if (!res.success) {
      setErrorMsg(res.error || 'Registration failed.');
    }
  };

  return (
    <div className="w-full max-w-xl mx-auto p-4 sm:p-6 pb-24 text-slate-100">
      {/* Header Badge */}
      <div className="text-center mb-6">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-emerald-600/20 border border-emerald-500/30 text-emerald-400 mb-3 shadow-lg shadow-emerald-950/50">
          <ShieldCheck className="w-8 h-8" />
        </div>
        <h1 className="text-2xl font-black text-white tracking-tight">{t.appName}</h1>
        <p className="text-xs text-emerald-400 font-semibold tracking-wide uppercase mt-0.5">
          {t.registerTitle}
        </p>
        <p className="text-xs text-slate-400 mt-2 max-w-sm mx-auto leading-relaxed">
          {t.privacyNoticeBadge}
        </p>
      </div>

      {/* Safety Notice Card */}
      <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 text-xs text-slate-300 mb-6 flex items-start gap-3 shadow-sm">
        <Info className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <span className="font-semibold text-emerald-300">Privacy Safeguard:</span> Your NID number, phone, email, date of birth, and addresses are strictly shielded. Other users can never view your private information.
        </div>
      </div>

      {/* Error alert */}
      {errorMsg && (
        <div className="p-4 mb-6 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs flex items-start gap-3 animate-shake">
          <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="flex-1 font-medium leading-relaxed">{errorMsg}</div>
        </div>
      )}

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* SECTION 1: Personal Identity */}
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider border-b border-slate-800 pb-2">
            <UserCheck className="w-4 h-4" />
            1. Identity & Age Verification
          </div>

          {/* Full Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {t.fullNameLabel} <span className="text-emerald-400">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Mohammad Sohel Rana"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-sm text-white placeholder-slate-500 outline-none transition"
            />
            <p className="text-[11px] text-slate-400 mt-1">Must match the legal name printed on your NID card.</p>
          </div>

          {/* Date of Birth & Calculated Age */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
                <span>{t.dobLabel} <span className="text-emerald-400">*</span></span>
              </label>
              <div className="relative">
                <input
                  type="date"
                  required
                  value={dob}
                  max={new Date().toISOString().split('T')[0]}
                  onChange={(e) => setDob(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-sm text-white outline-none transition"
                />
              </div>
            </div>

            {/* Live Age Check Indicator */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {t.ageLabel} (18+ Mandatory)
              </label>
              <div
                className={`h-[42px] px-3.5 rounded-xl flex items-center justify-between border text-xs font-bold ${
                  calculatedAge === null
                    ? 'bg-slate-950 border-slate-800 text-slate-500'
                    : isAgeValid
                    ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                    : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
                }`}
              >
                <span>
                  {calculatedAge === null ? 'Select DOB' : `${calculatedAge} Years Old`}
                </span>
                {isAgeValid && (
                  <span className="flex items-center gap-1 text-[11px] text-emerald-400">
                    <CheckCircle className="w-3.5 h-3.5" /> 18+ Verified
                  </span>
                )}
                {isUnderAge && (
                  <span className="flex items-center gap-1 text-[11px] text-rose-400">
                    <AlertCircle className="w-3.5 h-3.5" /> Under 18 (Barred)
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Under 18 Warning Notice if user selected DOB under 18 */}
          {isUnderAge && (
            <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-500/40 text-xs text-rose-200 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <p className="leading-relaxed">
                {t.underAgeAlert} Individuals under 18 cannot create an account on CB Bangladesh.
              </p>
            </div>
          )}

          {/* Gender */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {t.genderLabel} <span className="text-emerald-400">*</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['male', 'female', 'other'] as const).map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() => setGender(g)}
                  className={`py-2 rounded-xl text-xs font-semibold border transition capitalize ${
                    gender === g
                      ? 'bg-emerald-600/20 border-emerald-500 text-emerald-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {t[g]}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* SECTION 2: National ID (NID) Details */}
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider border-b border-slate-800 pb-2">
            <CreditCard className="w-4 h-4" />
            2. National ID (NID / Smart Card)
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {t.nidNumberLabel} <span className="text-emerald-400">*</span>
            </label>
            <input
              type="text"
              required
              placeholder={t.nidPlaceholder}
              value={nidNumber}
              onChange={(e) => setNidNumber(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-sm text-white placeholder-slate-500 outline-none transition font-mono tracking-wider"
            />
            <p className="text-[11px] text-slate-400 mt-1">Accepts 10-digit Smart Card or 13/17-digit National ID.</p>
          </div>
        </div>

        {/* SECTION 3: Contact Details */}
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider border-b border-slate-800 pb-2">
            <Phone className="w-4 h-4" />
            3. Contact Information (Private)
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {t.phoneLabel} <span className="text-emerald-400">*</span>
              </label>
              <input
                type="tel"
                required
                placeholder="+880 17XX XXXXXX"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-sm text-white placeholder-slate-500 outline-none transition"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {t.emailLabel} <span className="text-emerald-400">*</span>
              </label>
              <input
                type="email"
                required
                placeholder="name@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-sm text-white placeholder-slate-500 outline-none transition"
              />
            </div>
          </div>
        </div>

        {/* SECTION 4: Addresses */}
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider border-b border-slate-800 pb-2">
            <MapPin className="w-4 h-4" />
            4. Addresses
          </div>

          {/* Permanent Address */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-white">
              {t.permanentAddressLabel} <span className="text-emerald-400">*</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <span className="text-[11px] text-slate-400 block mb-1">{t.divisionLabel}</span>
                <select
                  value={permDivision}
                  onChange={(e) => {
                    setPermDivision(e.target.value);
                    const districts = BD_DISTRICTS[e.target.value] || [];
                    if (districts.length > 0) setPermDistrict(districts[0]);
                  }}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-emerald-500"
                >
                  {BD_DIVISIONS.map((div) => (
                    <option key={div} value={div}>{div}</option>
                  ))}
                </select>
              </div>

              <div>
                <span className="text-[11px] text-slate-400 block mb-1">{t.districtLabel}</span>
                <select
                  value={permDistrict}
                  onChange={(e) => setPermDistrict(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-emerald-500"
                >
                  {(BD_DISTRICTS[permDivision] || []).map((dst) => (
                    <option key={dst} value={dst}>{dst}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
              <input
                type="text"
                placeholder={t.upazilaLabel}
                value={permUpazila}
                onChange={(e) => setPermUpazila(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 outline-none focus:border-emerald-500"
              />
              <input
                type="text"
                placeholder={t.addressDetailsLabel}
                value={permDetails}
                onChange={(e) => setPermDetails(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Same as permanent checkbox */}
          <div className="pt-2 border-t border-slate-800/80">
            <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-300">
              <input
                type="checkbox"
                checked={sameAsPermanent}
                onChange={(e) => setSameAsPermanent(e.target.checked)}
                className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-700 bg-slate-950"
              />
              {t.sameAsPermanent}
            </label>
          </div>

          {/* Current Address (if different) */}
          {!sameAsPermanent && (
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <label className="block text-xs font-bold text-white">
                {t.currentAddressLabel} <span className="text-emerald-400">*</span>
              </label>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-[11px] text-slate-400 block mb-1">{t.divisionLabel}</span>
                  <select
                    value={currDivision}
                    onChange={(e) => {
                      setCurrDivision(e.target.value);
                      const districts = BD_DISTRICTS[e.target.value] || [];
                      if (districts.length > 0) setCurrDistrict(districts[0]);
                    }}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-emerald-500"
                  >
                    {BD_DIVISIONS.map((div) => (
                      <option key={div} value={div}>{div}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <span className="text-[11px] text-slate-400 block mb-1">{t.districtLabel}</span>
                  <select
                    value={currDistrict}
                    onChange={(e) => setCurrDistrict(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-emerald-500"
                  >
                    {(BD_DISTRICTS[currDivision] || []).map((dst) => (
                      <option key={dst} value={dst}>{dst}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                <input
                  type="text"
                  placeholder={t.upazilaLabel}
                  value={currUpazila}
                  onChange={(e) => setCurrUpazila(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 outline-none focus:border-emerald-500"
                />
                <input
                  type="text"
                  placeholder={t.addressDetailsLabel}
                  value={currDetails}
                  onChange={(e) => setCurrDetails(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          )}
        </div>

        {/* SECTION 5: Security Password */}
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider border-b border-slate-800 pb-2">
            <Lock className="w-4 h-4" />
            5. Security Credentials
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {t.passwordLabel} <span className="text-emerald-400">*</span>
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="Min. 6 characters"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-sm text-white placeholder-slate-500 outline-none transition pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {t.confirmPasswordLabel} <span className="text-emerald-400">*</span>
              </label>
              <input
                type="password"
                required
                placeholder="Repeat password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-sm text-white placeholder-slate-500 outline-none transition"
              />
            </div>
          </div>
        </div>

        {/* SECTION 6: Terms & Conditions Agreement */}
        <div className="p-4 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 space-y-3">
          <div className="flex items-start gap-3">
            <input
              type="checkbox"
              id="terms-check"
              required
              checked={termsAccepted}
              onChange={(e) => setTermsAccepted(e.target.checked)}
              className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-700 bg-slate-950 mt-1"
            />
            <label htmlFor="terms-check" className="text-xs text-slate-300 leading-relaxed cursor-pointer select-none">
              {t.termsAgreement}{' '}
              <button
                type="button"
                onClick={() => setShowTermsModal(true)}
                className="text-emerald-400 hover:underline font-bold inline-block"
              >
                ({t.viewTerms})
              </button>
            </label>
          </div>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isSubmitting || isUnderAge}
          className={`w-full py-3.5 px-6 rounded-2xl font-bold text-sm text-white flex items-center justify-center gap-2 shadow-xl transition active:scale-[0.99] ${
            isUnderAge
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
              : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-900/50 hover:shadow-emerald-900/70'
          }`}
        >
          {isSubmitting ? (
            <span className="inline-flex items-center gap-2">
              <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Verifying NID & Age...
            </span>
          ) : (
            <>
              <span>{t.registerButton}</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>

        {/* Switch to login */}
        <div className="text-center pt-2">
          <button
            type="button"
            onClick={onSwitchToLogin}
            className="text-xs text-slate-400 hover:text-emerald-400 transition"
          >
            {t.haveAccount}
          </button>
        </div>
      </form>

      {/* Terms Modal Dialog */}
      <TermsModal
        isOpen={showTermsModal}
        onClose={() => setShowTermsModal(false)}
        onAccept={() => setTermsAccepted(true)}
      />
    </div>
  );
};
