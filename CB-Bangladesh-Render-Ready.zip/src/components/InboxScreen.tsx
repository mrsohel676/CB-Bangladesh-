import React, { useState, useEffect, useCallback } from 'react';
import {
  ShieldCheck,
  Search,
  MessageSquarePlus,
  Lock,
  User,
  CheckCheck,
  Check,
  X,
  Plus,
  Shield,
  Sparkles,
} from 'lucide-react';
import { Conversation, PublicUser } from '../types';
import { useAuth } from '../context/AuthContext';
import { translations } from '../utils/i18n';

interface InboxScreenProps {
  onSelectConversation: (conversationId: string, otherUser: PublicUser) => void;
  onOpenOfficialChat: () => void;
}

export const InboxScreen: React.FC<InboxScreenProps> = ({
  onSelectConversation,
  onOpenOfficialChat,
}) => {
  const { user, token, language } = useAuth();
  const t = translations[language];

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  // New Chat Modal & Verified Directory
  const [showNewChatModal, setShowNewChatModal] = useState(false);
  const [directoryUsers, setDirectoryUsers] = useState<PublicUser[]>([]);
  const [directorySearch, setDirectorySearch] = useState('');
  const [isStartingChat, setIsStartingChat] = useState(false);

  const fetchConversations = useCallback(async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/conversations', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setConversations(data.conversations);
      }
    } catch (err) {
      console.error('Failed to load conversations:', err);
    } finally {
      setIsLoading(false);
    }
  }, [token]);

  useEffect(() => {
    fetchConversations();
    const interval = setInterval(fetchConversations, 4000);
    return () => clearInterval(interval);
  }, [fetchConversations]);

  // Fetch verified directory users when modal opens
  const fetchDirectory = async (query = '') => {
    if (!token) return;
    try {
      const res = await fetch(`/api/users/search?q=${encodeURIComponent(query)}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setDirectoryUsers(data.users);
      }
    } catch (err) {
      console.error('Failed to search directory:', err);
    }
  };

  const handleOpenNewChatModal = () => {
    setShowNewChatModal(true);
    fetchDirectory('');
  };

  const handleStartChatWithUser = async (targetUser: PublicUser) => {
    if (!token || isStartingChat) return;
    setIsStartingChat(true);

    try {
      const res = await fetch('/api/conversations/start', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ targetUserId: targetUser.id }),
      });

      if (res.ok) {
        const data = await res.json();
        setShowNewChatModal(false);
        onSelectConversation(data.conversation.id, targetUser);
      }
    } catch (err) {
      console.error('Failed to start conversation:', err);
    } finally {
      setIsStartingChat(false);
    }
  };

  // Filter conversations
  const filteredConversations = conversations.filter((c) => {
    const name = c.otherParticipant?.fullName || '';
    return name.toLowerCase().includes(searchQuery.toLowerCase());
  });

  // Find Official Admin conversation
  const officialConv = conversations.find((c) => c.isOfficialAdminChat || c.participants.includes('admin-cb-official'));
  const regularConversations = filteredConversations.filter(
    (c) => !(c.isOfficialAdminChat || c.participants.includes('admin-cb-official'))
  );

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 relative">
      {/* Android Top App Bar */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 space-y-3 shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-600/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-base font-black text-white tracking-tight">{t.appName}</h1>
              <p className="text-[11px] text-slate-400 font-medium">Private 1-on-1 Inbox</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold px-2 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/30 text-emerald-300 flex items-center gap-1">
              <Lock className="w-3 h-3 text-emerald-400" />
              Shield Active
            </span>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <input
            type="text"
            placeholder={t.searchPlaceholder}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:border-emerald-500 outline-none transition"
          />
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>
      </div>

      {/* Conversations List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3 custom-scrollbar pb-24">
        {/* PINNED: Official CB Bangladesh Admin Account Card */}
        <div className="space-y-1.5">
          <div className="flex items-center gap-1.5 px-1 text-[11px] font-bold text-emerald-400 uppercase tracking-wider">
            <Shield className="w-3.5 h-3.5" />
            Official Channel
          </div>

          <button
            onClick={() => {
              if (officialConv && officialConv.otherParticipant) {
                onSelectConversation(officialConv.id, officialConv.otherParticipant);
              } else {
                onOpenOfficialChat();
              }
            }}
            className="w-full p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/70 via-slate-900 to-slate-900 border border-emerald-500/40 hover:border-emerald-400 flex items-center gap-3 text-left transition shadow-md group relative overflow-hidden"
          >
            <div className="relative shrink-0">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center font-bold text-lg shadow-md border border-emerald-400/40">
                🛡️
              </div>
              <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-slate-900 flex items-center justify-center text-[9px] text-white font-black">
                ✓
              </span>
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-1 mb-0.5">
                <h3 className="text-xs font-black text-white group-hover:text-emerald-300 transition flex items-center gap-1.5 truncate">
                  CB Bangladesh Official
                  <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-bold border border-emerald-500/30">
                    Admin
                  </span>
                </h3>
                {officialConv?.lastMessage?.createdAt && (
                  <span className="text-[10px] text-slate-400 shrink-0">
                    {new Date(officialConv.lastMessage.createdAt).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-300 truncate">
                {officialConv?.lastMessage?.text ||
                  'Official Support, verification requests & safety compliance.'}
              </p>
            </div>

            {officialConv?.unreadCount && officialConv.unreadCount > 0 ? (
              <span className="w-5 h-5 rounded-full bg-emerald-500 text-slate-950 font-bold text-[10px] flex items-center justify-center shrink-0">
                {officialConv.unreadCount}
              </span>
            ) : null}
          </button>
        </div>

        {/* Regular Conversations List */}
        <div className="pt-2 space-y-1.5">
          <div className="flex items-center justify-between px-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            <span>Direct Conversations</span>
            <span className="text-[10px] text-slate-400 font-normal">
              {regularConversations.length} Active
            </span>
          </div>

          {isLoading ? (
            <div className="py-8 text-center">
              <div className="w-6 h-6 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto" />
            </div>
          ) : regularConversations.length === 0 ? (
            <div className="py-10 px-4 text-center rounded-2xl bg-slate-900/40 border border-slate-800/80 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-slate-400 mx-auto">
                <User className="w-5 h-5" />
              </div>
              <p className="text-xs text-slate-300 font-semibold">No direct conversations yet</p>
              <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                Tap the button below to start a private 1-on-1 conversation with a verified citizen.
              </p>
              <button
                onClick={handleOpenNewChatModal}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs inline-flex items-center gap-1.5 shadow transition"
              >
                <Plus className="w-3.5 h-3.5" />
                {t.newChat}
              </button>
            </div>
          ) : (
            regularConversations.map((conv) => {
              const other = conv.otherParticipant || {
                id: 'unknown',
                fullName: 'Verified Citizen',
                isNidVerified: true,
                role: 'user',
              };

              const timeString = conv.lastMessage?.createdAt
                ? new Date(conv.lastMessage.createdAt).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })
                : '';

              const isUnread = (conv.unreadCount || 0) > 0;

              return (
                <button
                  key={conv.id}
                  onClick={() => onSelectConversation(conv.id, other)}
                  className={`w-full p-3 rounded-2xl border transition flex items-center gap-3 text-left ${
                    isUnread
                      ? 'bg-slate-900 border-emerald-500/40 shadow-sm'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {/* Avatar */}
                  <div className="relative shrink-0">
                    <div className="w-11 h-11 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-emerald-400 font-bold text-xs">
                      {other.fullName.substring(0, 2).toUpperCase()}
                    </div>
                    {other.isNidVerified && (
                      <span className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-emerald-500 border-2 border-slate-900 rounded-full flex items-center justify-center text-[8px] text-white">
                        ✓
                      </span>
                    )}
                  </div>

                  {/* Name & snippet */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1 mb-0.5">
                      <h4 className="text-xs font-bold text-white truncate flex items-center gap-1">
                        {other.fullName}
                      </h4>
                      <span className="text-[10px] text-slate-400 shrink-0">{timeString}</span>
                    </div>
                    <p
                      className={`text-xs truncate ${
                        isUnread ? 'text-emerald-300 font-semibold' : 'text-slate-400'
                      }`}
                    >
                      {conv.lastMessage?.hasImage && '📷 '}
                      {conv.lastMessage?.text || 'No messages'}
                    </p>
                  </div>

                  {/* Unread badge */}
                  {isUnread && (
                    <span className="w-5 h-5 rounded-full bg-emerald-500 text-slate-950 font-bold text-[10px] flex items-center justify-center shrink-0">
                      {conv.unreadCount}
                    </span>
                  )}
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* Floating Action Button (FAB - Android Style) */}
      <button
        onClick={handleOpenNewChatModal}
        className="fixed bottom-20 right-6 sm:absolute sm:bottom-20 sm:right-6 w-14 h-14 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center shadow-xl shadow-emerald-950/70 hover:scale-105 active:scale-95 transition z-30"
        aria-label="New Message"
      >
        <MessageSquarePlus className="w-6 h-6" />
      </button>

      {/* Start New Chat Modal with Verified Users Directory */}
      {showNewChatModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md max-h-[80vh] flex flex-col shadow-2xl overflow-hidden">
            {/* Modal Header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-600/20 text-emerald-400 flex items-center justify-center">
                  <User className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Verified Users Directory</h3>
                  <p className="text-[10px] text-slate-400">PII Data is Shielded</p>
                </div>
              </div>
              <button
                onClick={() => setShowNewChatModal(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Search within Directory */}
            <div className="p-3 border-b border-slate-800 bg-slate-950/50">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search by verified citizen name..."
                  value={directorySearch}
                  onChange={(e) => {
                    setDirectorySearch(e.target.value);
                    fetchDirectory(e.target.value);
                  }}
                  className="w-full pl-8 pr-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:border-emerald-500 outline-none"
                />
                <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            {/* Directory Users List */}
            <div className="flex-1 overflow-y-auto p-3 space-y-2 custom-scrollbar">
              {directoryUsers.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-400">
                  No verified users matching search.
                </div>
              ) : (
                directoryUsers.map((target) => (
                  <button
                    key={target.id}
                    onClick={() => handleStartChatWithUser(target)}
                    className="w-full p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-emerald-500/50 flex items-center justify-between text-left transition group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-emerald-400 font-bold text-xs">
                        {target.role === 'admin' ? '🛡️' : target.fullName.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <p className="text-xs font-bold text-white group-hover:text-emerald-300 transition flex items-center gap-1.5">
                          {target.fullName}
                          {target.role === 'admin' && (
                            <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-1 py-0.5 rounded font-bold">
                              Official
                            </span>
                          )}
                        </p>
                        <p className="text-[10px] text-slate-400 flex items-center gap-1">
                          <ShieldCheck className="w-3 h-3 text-emerald-400" />
                          <span>NID Verified Citizen</span>
                        </p>
                      </div>
                    </div>
                    <span className="text-xs font-semibold text-emerald-400 group-hover:underline">
                      Message
                    </span>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
