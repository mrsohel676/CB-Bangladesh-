import React, { useState } from 'react';
import {
  ShieldCheck,
  User,
  Lock,
  Calendar,
  Phone,
  Mail,
  MapPin,
  CreditCard,
  LogOut,
  Globe,
  Edit3,
  CheckCircle,
  Save,
  Info,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { translations } from '../utils/i18n';
import { BD_DIVISIONS, BD_DISTRICTS } from '../utils/bangladeshLocations';

export const ProfileScreen: React.FC = () => {
  const { user, updateProfile, logout, language, setLanguage } = useAuth();
  const t = translations[language];

  const [isEditing, setIsEditing] = useState(false);
  const [currDivision, setCurrDivision] = useState(user?.currentAddress?.division || 'Dhaka');
  const [currDistrict, setCurrDistrict] = useState(user?.currentAddress?.district || 'Dhaka');
  const [currUpazila, setCurrUpazila] = useState(user?.currentAddress?.upazila || '');
  const [currDetails, setCurrDetails] = useState(user?.currentAddress?.details || '');

  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  if (!user) return null;

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    const res = await updateProfile({
      currentAddress: {
        division: currDivision,
        district: currDistrict,
        upazila: currUpazila.trim(),
        details: currDetails.trim(),
      },
    });
    setIsSaving(false);

    if (res.success) {
      setSaveSuccess(true);
      setIsEditing(false);
      setTimeout(() => setSaveSuccess(false), 3000);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 pb-24 overflow-y-auto custom-scrollbar p-4 space-y-5">
      {/* Profile Header Card */}
      <div className="p-5 rounded-3xl bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="w-16 h-16 rounded-full bg-slate-800 border-2 border-emerald-500/50 flex items-center justify-center font-black text-xl text-emerald-400">
              {user.role === 'admin' ? '🛡️' : user.fullName.substring(0, 2).toUpperCase()}
            </div>
            {user.isNidVerified && (
              <span className="absolute bottom-0 right-0 w-5 h-5 bg-emerald-500 border-2 border-slate-900 rounded-full flex items-center justify-center text-[10px] text-white font-bold">
                ✓
              </span>
            )}
          </div>

          <div className="min-w-0 flex-1">
            <h2 className="text-base font-black text-white tracking-tight truncate flex items-center gap-2">
              {user.fullName}
              {user.role === 'admin' && (
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-bold">
                  Official Admin
                </span>
              )}
            </h2>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-500/40 text-emerald-300 inline-flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                NID Verified Citizen (18+)
              </span>
            </div>
          </div>
        </div>

        {/* Language switch button */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-400 font-semibold">
            <Globe className="w-4 h-4 text-emerald-400" />
            <span>Language / ভাষা</span>
          </div>
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setLanguage('en')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                language === 'en' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              English
            </button>
            <button
              onClick={() => setLanguage('bn')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                language === 'bn' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              বাংলা
            </button>
          </div>
        </div>
      </div>

      {/* Save Success Alert */}
      {saveSuccess && (
        <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2 font-bold animate-fade-in">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          Profile updated successfully.
        </div>
      )}

      {/* Privacy Guarantee Card */}
      <div className="p-4 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 space-y-2">
        <div className="flex items-center gap-2 text-emerald-300 font-bold text-xs">
          <Lock className="w-4 h-4 text-emerald-400" />
          {t.profilePrivacyTitle}
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          {t.shieldedInfo}
        </p>
      </div>

      {/* Verified Personal Details Section */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-emerald-400" />
            Verified Identity Records
          </h3>
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="text-xs font-bold text-emerald-400 hover:underline flex items-center gap-1"
          >
            <Edit3 className="w-3.5 h-3.5" />
            {isEditing ? 'Cancel Edit' : 'Edit Address'}
          </button>
        </div>

        {/* Readonly Identity attributes */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-[10px] text-slate-400 block mb-0.5">National ID Number (NID)</span>
            <span className="font-mono font-bold text-white tracking-wider">{user.nidNumber}</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-[10px] text-slate-400 block mb-0.5">Date of Birth & Age</span>
            <span className="font-semibold text-emerald-300">
              {user.dob} ({user.age} Years Old)
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-[10px] text-slate-400 block mb-0.5">{t.phoneLabel}</span>
            <span className="font-medium text-white">{user.phone}</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-[10px] text-slate-400 block mb-0.5">{t.emailLabel}</span>
            <span className="font-medium text-white truncate block">{user.email}</span>
          </div>
        </div>

        {/* Permanent Address */}
        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-xs">
          <span className="text-[10px] text-slate-400 block mb-0.5">{t.permanentAddressLabel}</span>
          <span className="text-white font-medium">
            {user.permanentAddress?.division}, {user.permanentAddress?.district}, {user.permanentAddress?.upazila} ({user.permanentAddress?.details})
          </span>
        </div>

        {/* Current Address (Editable) */}
        {isEditing ? (
          <form onSubmit={handleSaveProfile} className="p-4 rounded-xl bg-slate-950 border border-emerald-500/40 space-y-3">
            <span className="text-xs font-bold text-emerald-300 block">Edit Current Address</span>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <span className="text-[10px] text-slate-400 block mb-1">{t.divisionLabel}</span>
                <select
                  value={currDivision}
                  onChange={(e) => {
                    setCurrDivision(e.target.value);
                    const districts = BD_DISTRICTS[e.target.value] || [];
                    if (districts.length > 0) setCurrDistrict(districts[0]);
                  }}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white outline-none focus:border-emerald-500"
                >
                  {BD_DIVISIONS.map((div) => (
                    <option key={div} value={div}>{div}</option>
                  ))}
                </select>
              </div>

              <div>
                <span className="text-[10px] text-slate-400 block mb-1">{t.districtLabel}</span>
                <select
                  value={currDistrict}
                  onChange={(e) => setCurrDistrict(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white outline-none focus:border-emerald-500"
                >
                  {(BD_DISTRICTS[currDivision] || []).map((dst) => (
                    <option key={dst} value={dst}>{dst}</option>
                  ))}
                </select>
              </div>
            </div>

            <input
              type="text"
              placeholder={t.upazilaLabel}
              value={currUpazila}
              onChange={(e) => setCurrUpazila(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white outline-none focus:border-emerald-500"
            />

            <input
              type="text"
              placeholder={t.addressDetailsLabel}
              value={currDetails}
              onChange={(e) => setCurrDetails(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white outline-none focus:border-emerald-500"
            />

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-3 py-1.5 rounded-xl border border-slate-700 text-xs text-slate-300 font-semibold"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSaving}
                className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save Changes</span>
              </button>
            </div>
          </form>
        ) : (
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-xs">
            <span className="text-[10px] text-slate-400 block mb-0.5">{t.currentAddressLabel}</span>
            <span className="text-white font-medium">
              {user.currentAddress?.division}, {user.currentAddress?.district}, {user.currentAddress?.upazila} ({user.currentAddress?.details})
            </span>
          </div>
        )}
      </div>

      {/* Logout button */}
      <button
        onClick={logout}
        className="w-full py-3 rounded-2xl bg-rose-950/40 border border-rose-500/30 text-rose-300 hover:bg-rose-900/40 font-bold text-xs flex items-center justify-center gap-2 transition"
      >
        <LogOut className="w-4 h-4" />
        <span>{t.logout}</span>
      </button>
    </div>
  );
};
