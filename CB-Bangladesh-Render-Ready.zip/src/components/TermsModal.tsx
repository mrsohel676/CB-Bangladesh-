import React from 'react';
import { ShieldCheck, X, FileText, CheckCircle2, Lock, EyeOff, AlertTriangle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { translations } from '../utils/i18n';

interface TermsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAccept?: () => void;
}

export const TermsModal: React.FC<TermsModalProps> = ({ isOpen, onClose, onAccept }) => {
  const { language } = useAuth();
  const t = translations[language];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl w-full max-w-2xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 bg-slate-950 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white leading-snug">{t.termsTitle}</h2>
              <p className="text-xs text-slate-400">Version 2.4 • Effective 2026</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm text-slate-300 leading-relaxed custom-scrollbar">
          {/* Key Pill Highlight */}
          <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-500/30 flex items-start gap-3">
            <Lock className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-semibold text-emerald-300 text-sm">Strict Zero-Public-Social Architecture</h4>
              <p className="text-xs text-emerald-200/80 mt-1">
                CB Bangladesh is strictly a private, identity-verified 1-on-1 communication platform. There are NO public feeds, NO public profiles, NO public photo feeds, NO likes, and NO public comment threads.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <h3 className="font-bold text-white flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center text-xs text-emerald-400 border border-slate-700">1</span>
                Real Identity & NID Truthfulness
              </h3>
              <p className="text-slate-400 text-xs pl-8">
                All registrants must provide their accurate legal name according to their official Bangladesh National ID (NID) or Smart Card. Registering under false aliases, spoofed credentials, or stolen IDs is strictly prohibited and subject to immediate account termination.
              </p>
            </div>

            <div className="space-y-1.5">
              <h3 className="font-bold text-white flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center text-xs text-emerald-400 border border-slate-700">2</span>
                Mandatory 18+ Age Requirement
              </h3>
              <p className="text-slate-400 text-xs pl-8">
                CB Bangladesh is exclusively restricted to users aged 18 and older. The date of birth provided must accurately reflect an age of at least 18 years on the registration date. Minor accounts are barred by system-level validation.
              </p>
            </div>

            <div className="space-y-1.5">
              <h3 className="font-bold text-white flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center text-xs text-emerald-400 border border-slate-700">3</span>
                Total Privacy Shield for Personal Information
              </h3>
              <p className="text-slate-400 text-xs pl-8">
                Your phone number, email address, NID number, date of birth, permanent address, and current address are confidential. Other users cannot search, view, or extract these details. Only your verified display name and verified badge are visible in private message threads.
              </p>
            </div>

            <div className="space-y-1.5">
              <h3 className="font-bold text-white flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center text-xs text-emerald-400 border border-slate-700">4</span>
                Private 1-on-1 Messages & Photos
              </h3>
              <p className="text-slate-400 text-xs pl-8">
                Text messages and photo attachments are shared strictly inside the designated private 1-on-1 conversation between you and the recipient. You may not use the platform for fraud, extortion, defamation, or illegal acts under the Cyber Security laws of Bangladesh.
              </p>
            </div>

            <div className="space-y-1.5">
              <h3 className="font-bold text-white flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center text-xs text-emerald-400 border border-slate-700">5</span>
                CB Bangladesh Official Admin Oversight
              </h3>
              <p className="text-slate-400 text-xs pl-8">
                The official administrative account ("CB Bangladesh Official") has authorized security access to assist users, manage verification queues, investigate reported abuse, and ensure safe regulatory compliance.
              </p>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-500/30 flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <p className="text-xs text-amber-200/90">
              By proceeding with registration, you acknowledge that you are at least 18 years old and consent to verification of your NID details for platform integrity.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-800 text-xs font-semibold transition"
          >
            Close
          </button>
          {onAccept && (
            <button
              onClick={() => {
                onAccept();
                onClose();
              }}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition flex items-center gap-2 shadow-lg shadow-emerald-900/40"
            >
              <CheckCircle2 className="w-4 h-4" />
              {t.termsClose}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
