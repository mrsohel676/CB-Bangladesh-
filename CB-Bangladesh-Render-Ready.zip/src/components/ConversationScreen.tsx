import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ArrowLeft,
  ShieldCheck,
  Send,
  Image,
  Lock,
  MoreVertical,
  AlertTriangle,
  Info,
  CheckCheck,
  Check,
  X,
  Maximize2,
  Sparkles,
} from 'lucide-react';
import { Conversation, Message, PublicUser } from '../types';
import { useAuth } from '../context/AuthContext';
import { translations } from '../utils/i18n';

interface ConversationScreenProps {
  conversationId: string;
  onBack: () => void;
  targetUser?: PublicUser;
}

export const ConversationScreen: React.FC<ConversationScreenProps> = ({
  conversationId,
  onBack,
  targetUser,
}) => {
  const { user, token, language } = useAuth();
  const t = translations[language];

  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [imagePreviewModal, setImagePreviewModal] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);

  // Safety / Privacy & Report Modals
  const [showPrivacySheet, setShowPrivacySheet] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportReason, setReportReason] = useState('Inappropriate behavior / Spam');
  const [reportSuccess, setReportSuccess] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchMessages = useCallback(async () => {
    if (!token) return;
    try {
      const res = await fetch(`/api/conversations/${conversationId}/messages`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setMessages(data.messages);
      }
    } catch (err) {
      console.error('Failed to load messages:', err);
    } finally {
      setIsLoading(false);
    }
  }, [conversationId, token]);

  useEffect(() => {
    fetchMessages();
    const interval = setInterval(fetchMessages, 3000);
    return () => clearInterval(interval);
  }, [fetchMessages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!inputText.trim() && !selectedImage) || isSending || !token) return;

    setIsSending(true);
    const payload = {
      text: inputText.trim() || undefined,
      imageUrl: selectedImage || undefined,
    };

    try {
      const res = await fetch(`/api/conversations/${conversationId}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        const data = await res.json();
        setMessages((prev) => [...prev, data.message]);
        setInputText('');
        setSelectedImage(null);
      }
    } catch (err) {
      console.error('Failed to send message:', err);
    } finally {
      setIsSending(false);
    }
  };

  const handleImagePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Convert to base64
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        setSelectedImage(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleReportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !targetUser) return;

    try {
      const res = await fetch('/api/reports', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          reportedUserId: targetUser.id,
          conversationId,
          reason: reportReason,
        }),
      });

      if (res.ok) {
        setReportSuccess(true);
        setTimeout(() => {
          setShowReportModal(false);
          setReportSuccess(false);
        }, 2000);
      }
    } catch (err) {
      console.error('Failed to submit report:', err);
    }
  };

  const isOfficialAccount = targetUser?.role === 'admin' || targetUser?.fullName.includes('Official');

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 relative">
      {/* Top App Bar (Android Material 3) */}
      <div className="h-16 px-4 bg-slate-900/95 border-b border-slate-800 flex items-center justify-between z-20 backdrop-blur shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 -ml-2 rounded-full hover:bg-slate-800 text-slate-300 hover:text-white transition"
            aria-label="Back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          {/* Recipient Identity Avatar & Name */}
          <div className="flex items-center gap-2.5">
            <div className="relative">
              {targetUser?.avatar ? (
                <img
                  src={targetUser.avatar}
                  alt={targetUser.fullName}
                  className="w-10 h-10 rounded-full object-cover border border-emerald-500/40"
                />
              ) : (
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm ${
                    isOfficialAccount
                      ? 'bg-gradient-to-tr from-emerald-600 to-teal-400 text-white shadow-md'
                      : 'bg-slate-800 text-emerald-400 border border-slate-700'
                  }`}
                >
                  {isOfficialAccount ? '🛡️' : targetUser?.fullName.substring(0, 2).toUpperCase() || 'CB'}
                </div>
              )}
              <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-slate-900 rounded-full" />
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm font-bold text-white tracking-tight truncate max-w-[160px] sm:max-w-xs">
                  {targetUser?.fullName || (isOfficialAccount ? 'CB Bangladesh Official' : 'Verified User')}
                </h2>
                {isOfficialAccount ? (
                  <span className="flex items-center gap-0.5 text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-1.5 py-0.5 rounded-full border border-emerald-500/30">
                    <ShieldCheck className="w-3 h-3 text-emerald-400" />
                    Official
                  </span>
                ) : (
                  <span className="flex items-center gap-0.5 text-[10px] bg-slate-800 text-emerald-400 font-semibold px-1.5 py-0.5 rounded-full border border-slate-700">
                    <ShieldCheck className="w-3 h-3" />
                    NID Verified
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 flex items-center gap-1">
                <Lock className="w-2.5 h-2.5 text-emerald-500" />
                <span>Private 1-on-1 • Encrypted Channel</span>
              </p>
            </div>
          </div>
        </div>

        {/* Top actions */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setShowPrivacySheet(true)}
            title="Privacy Shield Information"
            className="p-2 rounded-full hover:bg-slate-800 text-slate-400 hover:text-emerald-400 transition"
          >
            <Info className="w-5 h-5" />
          </button>
          {!isOfficialAccount && (
            <button
              onClick={() => setShowReportModal(true)}
              title="Report User to Admin"
              className="p-2 rounded-full hover:bg-slate-800 text-slate-400 hover:text-rose-400 transition"
            >
              <AlertTriangle className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Strict Privacy Shield Notification Banner */}
      <div className="bg-emerald-950/40 border-b border-emerald-500/20 px-4 py-2 flex items-center justify-between text-[11px] text-emerald-200">
        <div className="flex items-center gap-2 truncate">
          <Lock className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span className="truncate">
            Identity-Shielded: Your phone, email, NID, and address are hidden from this user.
          </span>
        </div>
        <button
          onClick={() => setShowPrivacySheet(true)}
          className="text-emerald-400 hover:underline font-bold shrink-0 ml-2"
        >
          Details
        </button>
      </div>

      {/* Messages Feed */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
        {isLoading ? (
          <div className="flex items-center justify-center h-48">
            <div className="w-6 h-6 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : messages.length === 0 ? (
          <div className="text-center py-12 px-4 space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-950/50 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mx-auto">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-white">{t.noMessages}</h3>
            <p className="text-xs text-slate-400 max-w-xs mx-auto leading-relaxed">
              {t.startChatting} Messages and photos sent here are 100% private between the two participants.
            </p>
          </div>
        ) : (
          messages.map((msg, index) => {
            const isMe = msg.senderId === user?.id;
            const isMsgOfficial = msg.senderId === 'admin-cb-official' || msg.senderName.includes('Official');
            const formattedTime = new Date(msg.createdAt).toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
            });

            return (
              <div
                key={msg.id || index}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
              >
                {/* Sender badge if not me */}
                {!isMe && (
                  <span className="text-[10px] font-semibold text-slate-400 mb-1 ml-1 flex items-center gap-1">
                    {msg.senderName}
                    {isMsgOfficial && (
                      <span className="text-[9px] bg-emerald-600/30 text-emerald-300 px-1 rounded">Official</span>
                    )}
                  </span>
                )}

                {/* Bubble Container */}
                <div
                  className={`max-w-[82%] sm:max-w-[70%] rounded-2xl p-3 shadow-md ${
                    isMe
                      ? 'bg-emerald-600 text-white rounded-tr-xs'
                      : isMsgOfficial
                      ? 'bg-slate-900 border border-emerald-500/40 text-slate-100 rounded-tl-xs'
                      : 'bg-slate-800 border border-slate-700/60 text-slate-100 rounded-tl-xs'
                  }`}
                >
                  {/* Image Attachment (Private Photo) */}
                  {msg.imageUrl && (
                    <div className="mb-2 rounded-xl overflow-hidden cursor-pointer relative group">
                      <img
                        src={msg.imageUrl}
                        alt="Private Photo"
                        className="w-full max-h-72 object-cover rounded-xl transition group-hover:opacity-95"
                        onClick={() => setImagePreviewModal(msg.imageUrl!)}
                      />
                      <button
                        onClick={() => setImagePreviewModal(msg.imageUrl!)}
                        className="absolute bottom-2 right-2 p-1.5 rounded-lg bg-black/60 text-white opacity-0 group-hover:opacity-100 transition backdrop-blur-sm"
                      >
                        <Maximize2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {/* Text Message */}
                  {msg.text && (
                    <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">{msg.text}</p>
                  )}

                  {/* Timestamp & Read Receipts */}
                  <div
                    className={`flex items-center justify-end gap-1 mt-1 text-[10px] ${
                      isMe ? 'text-emerald-100/75' : 'text-slate-400'
                    }`}
                  >
                    <span>{formattedTime}</span>
                    {isMe && (
                      <span>
                        {msg.readBy && msg.readBy.length > 1 ? (
                          <CheckCheck className="w-3.5 h-3.5 text-emerald-200" />
                        ) : (
                          <Check className="w-3.5 h-3.5 text-emerald-200/70" />
                        )}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Staged Image Attachment Preview */}
      {selectedImage && (
        <div className="px-4 py-2 bg-slate-900 border-t border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src={selectedImage}
              alt="Attachment Preview"
              className="w-14 h-14 object-cover rounded-xl border border-emerald-500"
            />
            <div className="text-xs">
              <p className="font-semibold text-emerald-300">Photo Attached (Private)</p>
              <p className="text-slate-400 text-[11px]">Ready to send securely</p>
            </div>
          </div>
          <button
            onClick={() => setSelectedImage(null)}
            className="p-1.5 rounded-full bg-slate-800 text-slate-300 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Input Form Bar (Android Bottom Input) */}
      <div className="p-3 bg-slate-900 border-t border-slate-800 shrink-0">
        <form onSubmit={handleSendMessage} className="flex items-center gap-2">
          {/* Photo upload trigger */}
          <input
            type="file"
            ref={fileInputRef}
            accept="image/*"
            className="hidden"
            onChange={handleImagePick}
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="p-2.5 rounded-full bg-slate-800 text-slate-300 hover:text-emerald-400 hover:bg-slate-700 transition"
            title="Attach Private Photo"
          >
            <Image className="w-5 h-5" />
          </button>

          {/* Text input */}
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder={t.sendPlaceholder}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="w-full px-4 py-2.5 rounded-full bg-slate-950 border border-slate-800 text-sm text-white placeholder-slate-500 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition"
            />
          </div>

          {/* Send Button */}
          <button
            type="submit"
            disabled={(!inputText.trim() && !selectedImage) || isSending}
            className={`p-2.5 rounded-full text-white font-bold transition shadow-md ${
              (!inputText.trim() && !selectedImage) || isSending
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-950/60'
            }`}
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
      </div>

      {/* Full Size Image Viewer Modal */}
      {imagePreviewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="relative max-w-3xl max-h-[90vh] flex flex-col items-center">
            <button
              onClick={() => setImagePreviewModal(null)}
              className="absolute -top-12 right-0 p-2 rounded-full bg-slate-800 text-white hover:bg-slate-700 transition"
            >
              <X className="w-6 h-6" />
            </button>
            <img
              src={imagePreviewModal}
              alt="Full Preview"
              className="max-h-[80vh] max-w-full object-contain rounded-2xl border border-slate-800"
            />
            <p className="text-xs text-slate-400 mt-3 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-emerald-400" />
              Private 1-on-1 encrypted image attachment.
            </p>
          </div>
        </div>
      )}

      {/* Privacy Information Bottom Sheet */}
      {showPrivacySheet && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-0 sm:p-4">
          <div className="bg-slate-900 border border-emerald-500/30 rounded-t-3xl sm:rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                <ShieldCheck className="w-5 h-5" />
                Privacy & Data Shield
              </div>
              <button
                onClick={() => setShowPrivacySheet(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-300">
              <p className="leading-relaxed">
                CB Bangladesh maintains strict zero-knowledge identity shielding between regular users.
              </p>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <p className="font-semibold text-white">What this user CAN see:</p>
                <ul className="list-disc pl-5 text-slate-400 space-y-1">
                  <li>Your verified legal name</li>
                  <li>Your NID Verified Badge</li>
                  <li>Messages and photos sent in this conversation</li>
                </ul>
              </div>

              <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30 space-y-2">
                <p className="font-semibold text-emerald-300">What is STRICTLY SHIELDED (Hidden):</p>
                <ul className="list-disc pl-5 text-emerald-200/80 space-y-1">
                  <li>Your National ID (NID) number</li>
                  <li>Your phone number & email address</li>
                  <li>Your date of birth & calculated age</li>
                  <li>Your permanent and current addresses</li>
                </ul>
              </div>
            </div>

            <button
              onClick={() => setShowPrivacySheet(false)}
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition"
            >
              Got It
            </button>
          </div>
        </div>
      )}

      {/* Report User Modal */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
          <div className="bg-slate-900 border border-rose-500/40 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
                <AlertTriangle className="w-5 h-5" />
                {t.reportModalTitle}
              </div>
              <button
                onClick={() => setShowReportModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {reportSuccess ? (
              <div className="p-4 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs text-center font-bold">
                ✓ Report submitted to CB Bangladesh Official for priority compliance review.
              </div>
            ) : (
              <form onSubmit={handleReportSubmit} className="space-y-4">
                <p className="text-xs text-slate-300 leading-relaxed">
                  Report <span className="font-semibold text-white">{targetUser?.fullName}</span> to CB Bangladesh Official for investigation.
                </p>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">
                    {t.reportReason}
                  </label>
                  <select
                    value={reportReason}
                    onChange={(e) => setReportReason(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-rose-500"
                  >
                    <option value="Inappropriate behavior / Spam">Inappropriate behavior / Spam</option>
                    <option value="Impersonation / Fake NID claims">Impersonation / Fake NID claims</option>
                    <option value="Harassment or abusive messaging">Harassment or abusive messaging</option>
                    <option value="Financial fraud / Scams">Financial fraud / Scams</option>
                    <option value="Other compliance violation">Other compliance violation</option>
                  </select>
                </div>

                <div className="flex gap-2 justify-end pt-2">
                  <button
                    type="button"
                    onClick={() => setShowReportModal(false)}
                    className="px-4 py-2 rounded-xl border border-slate-700 text-slate-300 text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition shadow"
                  >
                    {t.submitReport}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
