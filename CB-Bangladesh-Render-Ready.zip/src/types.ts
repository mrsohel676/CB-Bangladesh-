export interface Address {
  division: string;
  district: string;
  upazila: string;
  details: string;
}

export interface User {
  id: string;
  fullName: string;
  dob: string;
  age: number;
  gender: 'male' | 'female' | 'other';
  phone: string;
  email: string;
  permanentAddress: Address;
  currentAddress: Address;
  nidNumber: string;
  nidFrontImage?: string;
  nidBackImage?: string;
  isNidVerified: boolean;
  role: 'user' | 'admin';
  avatar?: string;
  termsAccepted: boolean;
  termsAcceptedAt: string;
  createdAt: string;
}

export interface PublicUser {
  id: string;
  fullName: string;
  isNidVerified: boolean;
  role: 'user' | 'admin';
  avatar?: string;
  createdAt?: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  text?: string;
  imageUrl?: string;
  createdAt: string;
  readBy: string[];
}

export interface Conversation {
  id: string;
  participants: string[];
  participantNames: Record<string, string>;
  isOfficialAdminChat?: boolean;
  lastMessage?: {
    text: string;
    senderId: string;
    createdAt: string;
    hasImage?: boolean;
  };
  updatedAt: string;
  unreadCount?: number;
  otherParticipant?: PublicUser;
}

export interface Report {
  id: string;
  reporterId: string;
  reportedUserId: string;
  conversationId: string;
  reason: string;
  createdAt: string;
  status: 'pending' | 'reviewed' | 'resolved';
}

export type ActiveTab = 'inbox' | 'official' | 'profile' | 'admin';
