/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AndroidContainer } from './components/AndroidContainer';
import { LoginScreen } from './components/LoginScreen';
import { RegisterScreen } from './components/RegisterScreen';
import { InboxScreen } from './components/InboxScreen';
import { ConversationScreen } from './components/ConversationScreen';
import { AdminDashboard } from './components/AdminDashboard';
import { ProfileScreen } from './components/ProfileScreen';
import { ActiveTab, PublicUser } from './types';

function MainApp() {
  const { user, isLoading, token } = useAuth();

  const [authView, setAuthView] = useState<'login' | 'register'>('login');
  const [activeTab, setActiveTab] = useState<ActiveTab>('inbox');

  // Active Conversation State
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);
  const [activeOtherUser, setActiveOtherUser] = useState<PublicUser | undefined>(undefined);

  // If Official Tab is clicked from bottom nav, find or create conversation with Official Admin
  const handleOpenOfficialChat = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/conversations/start', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ targetUserId: 'admin-cb-official' }),
      });

      if (res.ok) {
        const data = await res.json();
        const officialUser: PublicUser = {
          id: 'admin-cb-official',
          fullName: 'CB Bangladesh Official',
          isNidVerified: true,
          role: 'admin',
        };
        setActiveOtherUser(officialUser);
        setSelectedConversationId(data.conversation.id);
      }
    } catch (err) {
      console.error('Failed to open official chat:', err);
    }
  };

  const handleTabChange = (tab: ActiveTab) => {
    setSelectedConversationId(null);
    setActiveTab(tab);
    if (tab === 'official') {
      handleOpenOfficialChat();
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-slate-100">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs text-slate-400 font-semibold">Initializing CB Bangladesh...</p>
        </div>
      </div>
    );
  }

  // If user is not logged in, show Android auth container
  if (!user) {
    return (
      <AndroidContainer activeTab="inbox" onTabChange={() => {}} hideBottomNav={true}>
        <div className="flex-1 overflow-y-auto custom-scrollbar">
          {authView === 'login' ? (
            <LoginScreen onSwitchToRegister={() => setAuthView('register')} />
          ) : (
            <RegisterScreen onSwitchToLogin={() => setAuthView('login')} />
          )}
        </div>
      </AndroidContainer>
    );
  }

  // If inside active conversation screen
  if (selectedConversationId) {
    return (
      <AndroidContainer
        activeTab={activeTab}
        onTabChange={handleTabChange}
        hideBottomNav={true}
      >
        <ConversationScreen
          conversationId={selectedConversationId}
          targetUser={activeOtherUser}
          onBack={() => setSelectedConversationId(null)}
        />
      </AndroidContainer>
    );
  }

  return (
    <AndroidContainer activeTab={activeTab} onTabChange={handleTabChange}>
      <div className="flex-1 overflow-hidden flex flex-col">
        {activeTab === 'inbox' && (
          <InboxScreen
            onSelectConversation={(convId, targetUser) => {
              setActiveOtherUser(targetUser);
              setSelectedConversationId(convId);
            }}
            onOpenOfficialChat={handleOpenOfficialChat}
          />
        )}

        {activeTab === 'official' && (
          <div className="flex-1 flex items-center justify-center p-6 text-center">
            <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
            <p className="text-xs text-slate-400">Connecting to CB Bangladesh Official...</p>
          </div>
        )}

        {activeTab === 'admin' && <AdminDashboard />}

        {activeTab === 'profile' && <ProfileScreen />}
      </div>
    </AndroidContainer>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
