# CB Bangladesh — Render deployment

This folder is the Render-ready web/backend project. It must be uploaded to the **root of the GitHub repository** used by Render so that `package.json` is directly at the repository root.

Render settings:
- Build Command: `npm install && npm run build`
- Start Command: `npm start`
- Health Check Path: `/healthz`
- Environment: `NODE_ENV=production`

Registration requires age 18+ and a valid NID number format. NID card photo upload has been removed and is not required.
