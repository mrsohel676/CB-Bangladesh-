import express from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';

const app = express();
const PORT = Number(process.env.PORT) || 3000;

// Middleware for JSON/form request parsing. NID card images are not collected by registration.
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));

// Database file path
const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Data types
export interface UserRecord {
  id: string;
  fullName: string;
  dob: string; // YYYY-MM-DD
  age: number;
  gender: 'male' | 'female' | 'other';
  phone: string;
  email: string;
  passwordHash: string;
  permanentAddress: {
    division: string;
    district: string;
    upazila: string;
    details: string;
  };
  currentAddress: {
    division: string;
    district: string;
    upazila: string;
    details: string;
  };
  nidNumber: string;
  nidFrontImage?: string;
  nidBackImage?: string;
  isNidVerified: boolean;
  role: 'user' | 'admin';
  avatar?: string;
  termsAccepted: boolean;
  termsAcceptedAt: string;
  createdAt: string;
}

export interface MessageRecord {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  text?: string;
  imageUrl?: string;
  createdAt: string;
  readBy: string[];
}

export interface ConversationRecord {
  id: string;
  participants: string[]; // user IDs
  participantNames: Record<string, string>;
  isOfficialAdminChat?: boolean;
  lastMessage?: {
    text: string;
    senderId: string;
    createdAt: string;
    hasImage?: boolean;
  };
  updatedAt: string;
  unreadCount?: Record<string, number>;
}

export interface ReportRecord {
  id: string;
  reporterId: string;
  reportedUserId: string;
  conversationId: string;
  reason: string;
  createdAt: string;
  status: 'pending' | 'reviewed' | 'resolved';
}

export interface SessionRecord {
  token: string;
  userId: string;
  createdAt: string;
  expiresAt: string;
}

interface DatabaseSchema {
  users: UserRecord[];
  conversations: ConversationRecord[];
  messages: MessageRecord[];
  reports: ReportRecord[];
  sessions: SessionRecord[];
}

// Cryptographic Password Hashing (scrypt with random 16-byte salt)
function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derivedKey = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derivedKey}`;
}

function verifyPassword(password: string, storedHash: string): boolean {
  if (!storedHash) return false;
  if (!storedHash.includes(':')) {
    // Fallback for legacy test records
    return password === storedHash;
  }
  try {
    const [salt, key] = storedHash.split(':');
    if (!salt || !key) return false;
    const keyBuffer = Buffer.from(key, 'hex');
    const derivedBuffer = crypto.scryptSync(password, salt, 64);
    return crypto.timingSafeEqual(keyBuffer, derivedBuffer);
  } catch (err) {
    console.error('Password verification error:', err);
    return false;
  }
}

function generateSecureToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

// Initial Admin User & Seed
const ADMIN_ID = 'admin-cb-official';

function getInitialData(): DatabaseSchema {
  const adminUser: UserRecord = {
    id: ADMIN_ID,
    fullName: 'CB Bangladesh Official',
    dob: '1990-01-01',
    age: 36,
    gender: 'other',
    phone: '+8801700000000',
    email: 'admin@cb.bd',
    passwordHash: hashPassword('admin12345'),
    permanentAddress: {
      division: 'Dhaka',
      district: 'Dhaka',
      upazila: 'Gulshan',
      details: 'CB Bangladesh Headquarters, Level 12, Gulshan-2',
    },
    currentAddress: {
      division: 'Dhaka',
      district: 'Dhaka',
      upazila: 'Gulshan',
      details: 'CB Bangladesh Headquarters, Level 12, Gulshan-2',
    },
    nidNumber: '19901234567890123',
    isNidVerified: true,
    role: 'admin',
    avatar: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=150&auto=format&fit=crop&q=80',
    termsAccepted: true,
    termsAcceptedAt: new Date().toISOString(),
    createdAt: new Date().toISOString(),
  };

  return {
    users: [adminUser],
    conversations: [],
    messages: [],
    reports: [],
    sessions: [],
  };
}

// Read database
function readDB(): DatabaseSchema {
  try {
    if (!fs.existsSync(DB_FILE)) {
      const initial = getInitialData();
      fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2), 'utf-8');
      return initial;
    }
    const data = fs.readFileSync(DB_FILE, 'utf-8');
    const parsed = JSON.parse(data);
    if (!parsed.sessions) {
      parsed.sessions = [];
    }
    return parsed;
  } catch (err) {
    console.error('Error reading database file, returning default:', err);
    return getInitialData();
  }
}

// Write database
function writeDB(data: DatabaseSchema): void {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing database file:', err);
  }
}

// Helper: Calculate age strictly from DOB (YYYY-MM-DD)
function calculateAge(dobString: string): number {
  if (!dobString) return -1;
  const birthDate = new Date(dobString);
  if (isNaN(birthDate.getTime())) return -1;
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age;
}

// Helper: Normalize Bangladesh Phone Numbers to +8801XXXXXXXXX
function normalizeBdPhone(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  if (digits.startsWith('8801') && digits.length === 13) {
    return `+${digits}`;
  }
  if (digits.startsWith('01') && digits.length === 11) {
    return `+88${digits}`;
  }
  if (digits.startsWith('1') && digits.length === 10) {
    return `+880${digits}`;
  }
  return phone.trim();
}

// Helper: Strip sensitive PII for non-admin public search/display
function sanitizeUserForOthers(user: UserRecord) {
  return {
    id: user.id,
    fullName: user.fullName,
    isNidVerified: user.isNidVerified,
    role: user.role,
    avatar: user.avatar,
    createdAt: user.createdAt,
    // Strictly NO phone, email, NID, DOB, age, or addresses returned!
  };
}

// Helper: Current User Safe Profile (includes own info, strips passwordHash)
function sanitizeUserForSelf(user: UserRecord) {
  const { passwordHash, ...safe } = user;
  return safe;
}

// Token-based Auth helper
function authenticateUser(req: express.Request): UserRecord | null {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  const token = authHeader.split(' ')[1];
  if (!token) return null;

  const db = readDB();

  // 1. Check sessions table
  const session = db.sessions?.find(
    (s) => s.token === token && new Date(s.expiresAt).getTime() > Date.now()
  );
  if (session) {
    const user = db.users.find((u) => u.id === session.userId);
    if (user) return user;
  }

  // 2. Direct user ID lookup fallback (for admin seed token support)
  const user = db.users.find((u) => u.id === token);
  return user || null;
}

// Helper to create an authenticated session for user
function createSession(db: DatabaseSchema, userId: string): string {
  const token = generateSecureToken();
  const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(); // 30 days
  if (!db.sessions) db.sessions = [];
  db.sessions.push({
    token,
    userId,
    createdAt: new Date().toISOString(),
    expiresAt,
  });
  return token;
}

// ==========================================
// API ROUTES
// ==========================================

// Health Check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'CB Bangladesh Backend API', timestamp: new Date() });
});

// Render health check endpoint
app.get('/healthz', (req, res) => {
  res.status(200).json({ status: 'ok' });
});

// 1. User Registration (Fully Functional & Secure Real Identity Verification)
app.post('/api/auth/register', (req, res) => {
  try {
    const {
      fullName,
      dob,
      gender,
      phone,
      email,
      password,
      permanentAddress,
      currentAddress,
      nidNumber,
      termsAccepted,
    } = req.body;

    // Validate presence of all mandatory fields
    if (!fullName || typeof fullName !== 'string' || fullName.trim().length < 2) {
      return res.status(400).json({ error: 'Please enter your full legal name matching your National ID (minimum 2 characters).' });
    }

    if (!dob || typeof dob !== 'string') {
      return res.status(400).json({ error: 'Valid date of birth is required.' });
    }

    // Strict Age Verification (Must be 18 or older based on DOB)
    const age = calculateAge(dob);
    if (isNaN(age) || age < 18) {
      return res.status(400).json({
        error: 'Age requirement violation: You must be at least 18 years old to create an account on CB Bangladesh. Registration for individuals under 18 is strictly prohibited.',
        calculatedAge: age,
      });
    }

    if (age > 120) {
      return res.status(400).json({ error: 'Please enter a valid date of birth.' });
    }

    if (!gender || !['male', 'female', 'other'].includes(gender)) {
      return res.status(400).json({ error: 'Please select a valid gender option.' });
    }

    if (!phone || typeof phone !== 'string' || phone.trim().length < 8) {
      return res.status(400).json({ error: 'Please enter a valid mobile phone number.' });
    }

    const normalizedPhone = normalizeBdPhone(phone);

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || typeof email !== 'string' || !emailRegex.test(email.trim())) {
      return res.status(400).json({ error: 'Please enter a valid email address.' });
    }
    const cleanEmail = email.trim().toLowerCase();

    if (!password || typeof password !== 'string' || password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long for account security.' });
    }

    // NID Format check (10, 13, or 17 digits)
    const cleanNid = String(nidNumber || '').trim().replace(/\s+/g, '');
    if (!/^\d{10}$|^\d{13}$|^\d{17}$/.test(cleanNid)) {
      return res.status(400).json({ error: 'Please enter a valid 10, 13, or 17-digit Bangladesh National ID (NID) / Smart Card number.' });
    }

    // Terms & conditions verification (Mandatory)
    if (termsAccepted !== true) {
      return res.status(400).json({ error: 'You must review and accept the CB Bangladesh Terms & Conditions before completing registration.' });
    }

    // Address verification
    if (
      !permanentAddress ||
      !permanentAddress.division ||
      !permanentAddress.district ||
      !permanentAddress.upazila ||
      !permanentAddress.details
    ) {
      return res.status(400).json({ error: 'Please complete all fields for your permanent address (Division, District, Upazila/Thana, and Address Details).' });
    }

    if (
      !currentAddress ||
      !currentAddress.division ||
      !currentAddress.district ||
      !currentAddress.upazila ||
      !currentAddress.details
    ) {
      return res.status(400).json({ error: 'Please complete all fields for your current address (Division, District, Upazila/Thana, and Address Details).' });
    }

    const db = readDB();

    // Check duplicate phone
    const existingPhone = db.users.find((u) => u.phone === normalizedPhone || normalizeBdPhone(u.phone) === normalizedPhone);
    if (existingPhone) {
      return res.status(409).json({ error: 'An account with this phone number already exists in CB Bangladesh.' });
    }

    // Check duplicate email
    const existingEmail = db.users.find((u) => u.email.toLowerCase() === cleanEmail);
    if (existingEmail) {
      return res.status(409).json({ error: 'An account with this email address already exists.' });
    }

    // Check duplicate NID
    const existingNid = db.users.find((u) => u.nidNumber === cleanNid);
    if (existingNid) {
      return res.status(409).json({ error: 'An account with this National ID number has already been registered.' });
    }

    // Create new verified identity user with cryptographic password hash
    const newUserId = `cb-user-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const newUser: UserRecord = {
      id: newUserId,
      fullName: fullName.trim(),
      dob,
      age,
      gender,
      phone: normalizedPhone,
      email: cleanEmail,
      passwordHash: hashPassword(password),
      permanentAddress: {
        division: permanentAddress.division.trim(),
        district: permanentAddress.district.trim(),
        upazila: permanentAddress.upazila.trim(),
        details: permanentAddress.details.trim(),
      },
      currentAddress: {
        division: currentAddress.division.trim(),
        district: currentAddress.district.trim(),
        upazila: currentAddress.upazila.trim(),
        details: currentAddress.details.trim(),
      },
      nidNumber: cleanNid,
      isNidVerified: true, // Registration verifies age and NID-number format; no card image is required.
      role: 'user',
      termsAccepted: true,
      termsAcceptedAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };

    db.users.push(newUser);

    // Create session token
    const token = createSession(db, newUserId);

    // Auto-create initial official welcome conversation with CB Bangladesh Official
    const officialConvId = `conv-official-${newUserId}`;
    const officialConv: ConversationRecord = {
      id: officialConvId,
      participants: [newUserId, ADMIN_ID],
      participantNames: {
        [newUserId]: newUser.fullName,
        [ADMIN_ID]: 'CB Bangladesh Official',
      },
      isOfficialAdminChat: true,
      lastMessage: {
        text: `Welcome ${newUser.fullName}! Your verified identity registration and National ID (${cleanNid}) have been securely recorded. CB Bangladesh provides encrypted 1-on-1 private messaging with complete privacy shielding. Message this official channel anytime if you need assistance.`,
        senderId: ADMIN_ID,
        createdAt: new Date().toISOString(),
      },
      updatedAt: new Date().toISOString(),
      unreadCount: {
        [newUserId]: 1,
        [ADMIN_ID]: 0,
      },
    };

    const welcomeMessage: MessageRecord = {
      id: `msg-welcome-${Date.now()}`,
      conversationId: officialConvId,
      senderId: ADMIN_ID,
      senderName: 'CB Bangladesh Official',
      text: `Welcome ${newUser.fullName}! Your verified identity registration and National ID (${cleanNid}) have been securely recorded. CB Bangladesh provides encrypted 1-on-1 private messaging with complete privacy shielding. Message this official channel anytime if you need assistance.`,
      createdAt: new Date().toISOString(),
      readBy: [ADMIN_ID],
    };

    db.conversations.push(officialConv);
    db.messages.push(welcomeMessage);

    writeDB(db);

    res.status(201).json({
      message: 'Registration completed successfully with real identity verification.',
      token,
      user: sanitizeUserForSelf(newUser),
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Internal server error during registration.' });
  }
});

// 2. User Login (Cryptographically Verified)
app.post('/api/auth/login', (req, res) => {
  try {
    const { identifier, password } = req.body;
    if (!identifier || !password) {
      return res.status(400).json({ error: 'Phone/Email and password are required.' });
    }

    const db = readDB();
    const cleanId = String(identifier).trim().toLowerCase();
    const normalizedPhone = normalizeBdPhone(identifier);

    // Match by email, normalized phone, or admin username
    const user = db.users.find(
      (u) =>
        u.email.toLowerCase() === cleanId ||
        u.phone === cleanId ||
        normalizeBdPhone(u.phone) === normalizedPhone ||
        (cleanId === 'admin@cb.bd' && u.role === 'admin') ||
        (cleanId === 'admin' && u.role === 'admin')
    );

    if (!user || !verifyPassword(password, user.passwordHash)) {
      return res.status(401).json({ error: 'Invalid credentials. Please verify your phone/email and password.' });
    }

    // Create session token
    const token = createSession(db, user.id);
    writeDB(db);

    res.json({
      message: 'Login successful.',
      token,
      user: sanitizeUserForSelf(user),
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Server error during login.' });
  }
});

// 3. Current User Profile
app.get('/api/auth/me', (req, res) => {
  const user = authenticateUser(req);
  if (!user) {
    return res.status(401).json({ error: 'Unauthorized. Please login.' });
  }
  res.json({ user: sanitizeUserForSelf(user) });
});

// 4. Update Current User Profile
app.put('/api/auth/profile', (req, res) => {
  const user = authenticateUser(req);
  if (!user) {
    return res.status(401).json({ error: 'Unauthorized.' });
  }

  const { currentAddress, permanentAddress, avatar } = req.body;
  const db = readDB();
  const userIndex = db.users.findIndex((u) => u.id === user.id);

  if (userIndex === -1) {
    return res.status(404).json({ error: 'User not found.' });
  }

  if (currentAddress) db.users[userIndex].currentAddress = currentAddress;
  if (permanentAddress) db.users[userIndex].permanentAddress = permanentAddress;
  if (avatar !== undefined) db.users[userIndex].avatar = avatar;

  writeDB(db);
  res.json({ message: 'Profile updated successfully.', user: sanitizeUserForSelf(db.users[userIndex]) });
});

// 5. Search Verified Users (Privacy-Shielded)
app.get('/api/users/search', (req, res) => {
  const currentUser = authenticateUser(req);
  if (!currentUser) {
    return res.status(401).json({ error: 'Unauthorized.' });
  }

  const query = String(req.query.q || '').trim().toLowerCase();
  const db = readDB();

  // Filter users matching name, exclude current user
  let results = db.users.filter((u) => u.id !== currentUser.id);

  if (query) {
    results = results.filter(
      (u) =>
        u.fullName.toLowerCase().includes(query) ||
        u.id.toLowerCase().includes(query) ||
        (u.role === 'admin' && 'cb bangladesh official'.includes(query))
    );
  }

  // Strictly return sanitized objects (No phone, email, addresses, NID)
  const safeUsers = results.map((u) => sanitizeUserForOthers(u));
  res.json({ users: safeUsers });
});

// 6. Get User's Private Conversations
app.get('/api/conversations', (req, res) => {
  const currentUser = authenticateUser(req);
  if (!currentUser) {
    return res.status(401).json({ error: 'Unauthorized.' });
  }

  const db = readDB();
  // Filter conversations where current user is a participant
  const userConversations = db.conversations
    .filter((c) => c.participants.includes(currentUser.id))
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());

  // Enrich with participant public info
  const enriched = userConversations.map((c) => {
    const otherParticipantId = c.participants.find((p) => p !== currentUser.id) || ADMIN_ID;
    const otherUser = db.users.find((u) => u.id === otherParticipantId);

    return {
      ...c,
      otherParticipant: otherUser ? sanitizeUserForOthers(otherUser) : {
        id: otherParticipantId,
        fullName: c.participantNames[otherParticipantId] || 'User',
        isNidVerified: true,
        role: otherParticipantId === ADMIN_ID ? 'admin' : 'user',
      },
      unreadCount: c.unreadCount?.[currentUser.id] || 0,
    };
  });

  res.json({ conversations: enriched });
});

// 7. Start or Retrieve a Conversation
app.post('/api/conversations/start', (req, res) => {
  const currentUser = authenticateUser(req);
  if (!currentUser) {
    return res.status(401).json({ error: 'Unauthorized.' });
  }

  const { targetUserId } = req.body;
  if (!targetUserId) {
    return res.status(400).json({ error: 'targetUserId is required.' });
  }

  const db = readDB();
  const targetUser = db.users.find((u) => u.id === targetUserId);
  if (!targetUser) {
    return res.status(404).json({ error: 'Target user does not exist in verified directory.' });
  }

  // Check if conversation already exists between these 2
  let conv = db.conversations.find(
    (c) => c.participants.includes(currentUser.id) && c.participants.includes(targetUserId)
  );

  if (!conv) {
    const isOfficial = targetUserId === ADMIN_ID || currentUser.id === ADMIN_ID;
    const newConvId = `conv-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    conv = {
      id: newConvId,
      participants: [currentUser.id, targetUserId],
      participantNames: {
        [currentUser.id]: currentUser.fullName,
        [targetUserId]: targetUser.fullName,
      },
      isOfficialAdminChat: isOfficial,
      updatedAt: new Date().toISOString(),
      unreadCount: {
        [currentUser.id]: 0,
        [targetUserId]: 0,
      },
    };
    db.conversations.unshift(conv);
    writeDB(db);
  }

  res.json({
    conversation: {
      ...conv,
      otherParticipant: sanitizeUserForOthers(targetUser),
      unreadCount: 0,
    },
  });
});

// 8. Get Messages in a Conversation (Strict Authorization)
app.get('/api/conversations/:id/messages', (req, res) => {
  const currentUser = authenticateUser(req);
  if (!currentUser) {
    return res.status(401).json({ error: 'Unauthorized.' });
  }

  const { id } = req.params;
  const db = readDB();
  const conv = db.conversations.find((c) => c.id === id);

  if (!conv) {
    return res.status(404).json({ error: 'Conversation not found.' });
  }

  // Participant or Admin check
  if (!conv.participants.includes(currentUser.id) && currentUser.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied. You are not a participant in this private conversation.' });
  }

  // Mark messages as read for this user
  let hasUpdatedRead = false;
  db.messages.forEach((msg) => {
    if (msg.conversationId === id && !msg.readBy.includes(currentUser.id)) {
      msg.readBy.push(currentUser.id);
      hasUpdatedRead = true;
    }
  });

  // Reset unread count for current user
  if (conv.unreadCount && conv.unreadCount[currentUser.id]) {
    conv.unreadCount[currentUser.id] = 0;
    hasUpdatedRead = true;
  }

  if (hasUpdatedRead) {
    writeDB(db);
  }

  const conversationMessages = db.messages
    .filter((m) => m.conversationId === id)
    .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

  res.json({ messages: conversationMessages });
});

// 9. Send Private Message (Text or Image)
app.post('/api/conversations/:id/messages', (req, res) => {
  const currentUser = authenticateUser(req);
  if (!currentUser) {
    return res.status(401).json({ error: 'Unauthorized.' });
  }

  const { id } = req.params;
  const { text, imageUrl } = req.body;

  if (!text && !imageUrl) {
    return res.status(400).json({ error: 'Message must contain text or an image.' });
  }

  const db = readDB();
  const conv = db.conversations.find((c) => c.id === id);

  if (!conv) {
    return res.status(404).json({ error: 'Conversation not found.' });
  }

  // Must be participant or admin
  if (!conv.participants.includes(currentUser.id) && currentUser.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied.' });
  }

  const newMessage: MessageRecord = {
    id: `msg-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    conversationId: id,
    senderId: currentUser.id,
    senderName: currentUser.fullName,
    text: text ? text.trim() : undefined,
    imageUrl: imageUrl || undefined,
    createdAt: new Date().toISOString(),
    readBy: [currentUser.id],
  };

  db.messages.push(newMessage);

  // Update conversation last message & timestamp
  conv.lastMessage = {
    text: text ? text.trim() : (imageUrl ? '📷 Sent a private photo' : ''),
    senderId: currentUser.id,
    createdAt: newMessage.createdAt,
    hasImage: !!imageUrl,
  };
  conv.updatedAt = newMessage.createdAt;

  // Increment unread count for other participants
  if (!conv.unreadCount) conv.unreadCount = {};
  conv.participants.forEach((pId) => {
    if (pId !== currentUser.id) {
      conv.unreadCount![pId] = (conv.unreadCount![pId] || 0) + 1;
    }
  });

  writeDB(db);

  res.status(201).json({ message: newMessage });
});

// 10. Report User / Conversation to Admin
app.post('/api/reports', (req, res) => {
  const currentUser = authenticateUser(req);
  if (!currentUser) {
    return res.status(401).json({ error: 'Unauthorized.' });
  }

  const { reportedUserId, conversationId, reason } = req.body;
  if (!reportedUserId || !reason) {
    return res.status(400).json({ error: 'reportedUserId and reason are required.' });
  }

  const db = readDB();
  const newReport: ReportRecord = {
    id: `rep-${Date.now()}`,
    reporterId: currentUser.id,
    reportedUserId,
    conversationId: conversationId || '',
    reason,
    createdAt: new Date().toISOString(),
    status: 'pending',
  };

  db.reports.unshift(newReport);
  writeDB(db);

  res.status(201).json({ message: 'Report submitted to CB Bangladesh Official for investigation.', report: newReport });
});

// ==========================================
// ADMIN EXCLUSIVE ROUTES
// ==========================================

// Middleware: Admin check
function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
  const user = authenticateUser(req);
  if (!user || user.role !== 'admin') {
    return res.status(403).json({ error: 'Forbidden: Admin authorization required.' });
  }
  next();
}

// Admin: Get all conversations queue
app.get('/api/admin/conversations', requireAdmin, (req, res) => {
  const db = readDB();
  // Sort conversations by most recent message/update
  const allConversations = db.conversations
    .slice()
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .map((c) => {
      const usersInfo = c.participants.map((pId) => {
        const u = db.users.find((user) => user.id === pId);
        return u ? { id: u.id, fullName: u.fullName, phone: u.phone, isNidVerified: u.isNidVerified } : { id: pId, fullName: 'Unknown' };
      });
      return {
        ...c,
        participantsInfo: usersInfo,
      };
    });

  res.json({ conversations: allConversations });
});

// Admin: Get all registered users (Audit & Verification Review)
app.get('/api/admin/users', requireAdmin, (req, res) => {
  const db = readDB();
  const users = db.users.map((u) => sanitizeUserForSelf(u));
  res.json({ users });
});

// Admin: Verify / Update User Verification Status
app.patch('/api/admin/users/:id/verify', requireAdmin, (req, res) => {
  const { id } = req.params;
  const { isNidVerified } = req.body;
  const db = readDB();
  const user = db.users.find((u) => u.id === id);

  if (!user) {
    return res.status(404).json({ error: 'User not found.' });
  }

  user.isNidVerified = isNidVerified !== undefined ? isNidVerified : true;
  writeDB(db);

  res.json({ message: 'User verification status updated.', user: sanitizeUserForSelf(user) });
});

// Admin: Get Reports
app.get('/api/admin/reports', requireAdmin, (req, res) => {
  const db = readDB();
  res.json({ reports: db.reports });
});

// ==========================================
// STATIC ASSET & VITE MIDDLEWARE SETUP
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[CB Bangladesh] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
